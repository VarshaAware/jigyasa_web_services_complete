/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 18-May-2017
>  * FetchDetailsForEditControllerImplTest.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.Training;

/**
 * @author swathi.m
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class FetchDetailsForEditControllerImplTest {

	@Autowired
	private TestRestTemplate restTemplate;

	Training training;

	@Before
	public void setup() {

		training = new Training();
		training.setTrainingId(361);

	}

	@Test
	public void testFetchDetailsForEdit() throws Exception {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.FETCH_DETAILS_FOR_EDIT, training,
				Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
