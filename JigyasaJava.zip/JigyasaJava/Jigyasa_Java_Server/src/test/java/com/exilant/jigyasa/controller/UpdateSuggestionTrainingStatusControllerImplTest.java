package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.SuggestTraining;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class UpdateSuggestionTrainingStatusControllerImplTest {
	@Autowired
	private TestRestTemplate restTemplate;
	SuggestTraining testSuggestTrainingStatus = null;

	@Before
	public void setup() {
		testSuggestTrainingStatus = new SuggestTraining();
		testSuggestTrainingStatus.setEmployeeId(4343);
		testSuggestTrainingStatus.setTitle("XHtml");
		testSuggestTrainingStatus.setDescription("Training On XHtml");
		testSuggestTrainingStatus.setStatus("Created");

	}

	@Test
	public void testRequestManagerToNominateForTraining() throws Exception {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.UPDATE_SUGGEST_TRAINING_STATUS,
				testSuggestTrainingStatus, String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
