package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.SendEmail;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SendEmailControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;
	SendEmail sendMail = null;

	@Before
	public void setup() {
		ArrayList<String> sendEmailToList = new ArrayList<String>();
		sendEmailToList.add("varsha.sa@exilant.com");
		sendEmailToList.add("lakshmi.bhat@exilant.com");
		sendEmailToList.add("swathi.m@exilant.com");
		sendMail = new SendEmail();
		sendMail.setSubject("Test Jigaysa mail service");
		;
		sendMail.setTo(sendEmailToList);
		sendMail.setBody("MailService is working Fine");
		;
	}

	@Test
	public void test() {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.SEND_EMAIL, sendMail, Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
