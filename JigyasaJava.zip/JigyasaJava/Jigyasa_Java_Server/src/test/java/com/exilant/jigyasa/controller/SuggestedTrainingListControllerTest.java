package com.exilant.jigyasa.controller;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.TrainingList;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SuggestedTrainingListControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;
	TrainingList testTrainingList = null;

	@Before
	public void setup() {
		testTrainingList = new TrainingList();
		testTrainingList.setEmployeeId(1960);
		testTrainingList.setDesignation(1);
	}

	@Test
	public void testSuggestedTrainingList() throws Exception {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.REQUEST_TRAINING, testTrainingList,
				String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
