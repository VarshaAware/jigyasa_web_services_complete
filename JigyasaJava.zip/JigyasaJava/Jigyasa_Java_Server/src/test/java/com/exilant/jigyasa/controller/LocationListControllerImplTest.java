package com.exilant.jigyasa.controller;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.TrainingLocation;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class LocationListControllerImplTest {

	@Autowired
	private TestRestTemplate restTemplate;
	TrainingLocation trainingLocation ;
	
	@Before
	public void setup() {
		trainingLocation = new TrainingLocation();}
	
	@Test
	public void testLocationList() {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.LOCATION_LIST, trainingLocation,
				String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
