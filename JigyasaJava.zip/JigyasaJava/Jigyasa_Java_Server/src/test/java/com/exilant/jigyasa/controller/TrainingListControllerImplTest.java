/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 09-May-2017
  * TrainingListControllerImplTest.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.TrainingList;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class TrainingListControllerImplTest {

	@Autowired
	private TestRestTemplate restTemplate;

	TrainingList list = null;

	@Before
	public void setup() {
		list = new TrainingList();
		list.setDesignation(3);
		list.setEmployeeId(1960);
		list.setTrainingId(360);
	}

	/**
	 * Test method for
	 * {@link com.exilant.jigyasa.controller.impl.TrainingListControllerImpl#getTrainingList(com.exilant.jigyasa.vo.TrainingList)}.
	 */
	@Test
	public void testGetTrainingList() {
		ResponseEntity<TrainingListResponse> response = restTemplate.postForEntity(URIConstants.TRAINING_LIST, list,
				TrainingListResponse.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

	/**
	 * Test method for
	 * {@link com.exilant.jigyasa.controller.impl.TrainingListControllerImpl#getTrainingDetails(com.exilant.jigyasa.vo.TrainingList)}.
	 */
	@Test
	public void testGetTrainingDetails() {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.TRAINING_DETAILS, list, Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}
	
	@Test
	public void testGetTrainingHistory() {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.HISTORY, list, Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
