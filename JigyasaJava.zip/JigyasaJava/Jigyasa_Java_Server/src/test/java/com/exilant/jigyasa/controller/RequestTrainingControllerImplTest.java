package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.RequestTraining;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class RequestTrainingControllerImplTest {

	@Autowired
	private TestRestTemplate restTemplate;
	RequestTraining testRequestTraining = null;

	@Before
	public void setup() {
		testRequestTraining = new RequestTraining();
		testRequestTraining.setEmployeeId(4343);
		testRequestTraining.setManagerId(3639);
		testRequestTraining.setTrainingId(270);
	}

	@Test
	public void testRequestManagerToNominateForTraining() throws Exception {
		ResponseEntity<String> response = restTemplate.postForEntity(URIConstants.REQUEST_TRAINING, testRequestTraining,
				String.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
	}

}
