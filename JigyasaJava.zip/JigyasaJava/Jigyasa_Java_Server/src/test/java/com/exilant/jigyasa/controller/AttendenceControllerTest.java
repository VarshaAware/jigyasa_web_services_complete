package com.exilant.jigyasa.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.vo.AttendanceRequest;
import com.exilant.jigyasa.vo.RequestStatus;
import com.exilant.jigyasa.vo.RequestTraining;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AttendenceControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;

	RequestStatus markAttend;

	RequestTraining trainingObj;

	AttendanceRequest reqObj;

	@Before
	public void setup() {
		ArrayList<Integer> employeeIdList = new ArrayList<Integer>();
		employeeIdList.add(4302);
		employeeIdList.add(4343);
		markAttend = new RequestStatus();
		markAttend.setTrainingId(361);
		markAttend.setEmployeeId(employeeIdList);
		markAttend.setStartDate("2017-05-18 10:40:00");

		reqObj = new AttendanceRequest();
		reqObj.setDate("20-05-2017");
		reqObj.setTrainingId(361);

		trainingObj = new RequestTraining();
		trainingObj.setEmployeeId(1960);
		trainingObj.setTrainingId(431);
	}

	@Test
	public void testMarkAttendence() {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.MARK_ATTENDENCE, markAttend,
				Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		;
	}

	@Test
	public void testFetchAttendence() {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.FETCH_ATTENDENCE, reqObj,
				Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		;
	}

	@Test
	public void testFetchAttendeeList() {
		ResponseEntity<Object> response = restTemplate.postForEntity(URIConstants.FETCH_ATTENDEES, trainingObj,
				Object.class);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		;
	}
}
