/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * LoginServiceImplTest.java
  *
  *******************************************************/

package com.exilant.jigyasa.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.exilant.jigyasa.vo.User;

/**
 * @author lakshmi.bhat
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LoginServiceImplTest {

	@Autowired
	LoginService loginService;

	User user = null;

	@Before
	public void setup() {
		user = new User();
		user.setUserName("lakshmi.bhat");
		user.setPassword("Exilant123");
	}
	
	@Test
	public void testLoginService() {
		assertNotNull(loginService.loginService(user));
	}

	@Test
	public void testLoginServiceError() {
		user.setPassword("@123");
		assertNull(loginService.loginService(user));
	}
}
