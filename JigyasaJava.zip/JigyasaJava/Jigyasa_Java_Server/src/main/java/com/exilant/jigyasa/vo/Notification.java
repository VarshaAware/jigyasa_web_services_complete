/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * Notification.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

import java.util.List;

/**
 * @author swathi.m
 *
 */
public class Notification {
	private String type;
	private String subject;
	private String content;
	private String rcpType;
	private List<String> ccListId;

	public Notification() {
		super();
	}

	public Notification(String type, String subject, String content, String rcpType, List<String> ccListId) {
		super();
		this.type = type;
		this.subject = subject;
		this.content = content;
		this.rcpType = rcpType;
		this.ccListId = ccListId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRcpType() {
		return rcpType;
	}

	public void setRcpType(String rcpType) {
		this.rcpType = rcpType;
	}

	public List<String> getCcListId() {
		return ccListId;
	}

	public void setCcListId(List<String> ccListId) {
		this.ccListId = ccListId;
	}

	@Override
	public String toString() {
		return "Notification [type=" + type + ", subject=" + subject + ", content=" + content + ", rcpType=" + rcpType
				+ ", ccListId=" + ccListId + "]";
	}

}