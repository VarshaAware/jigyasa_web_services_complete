/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListService.java
  *
  *******************************************************/

package com.exilant.jigyasa.service;

import java.util.List;

import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.TrainingList;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
public interface TrainingListService {
	TrainingListResponse getTrainingList(TrainingList trainingList);

	MyTraining getTrainingDetails(TrainingList trainingList);

	/**
	 * @param trainingList
	 * @return
	 */
	List<MyTraining> getTrainingHistory(TrainingList trainingList);
}
