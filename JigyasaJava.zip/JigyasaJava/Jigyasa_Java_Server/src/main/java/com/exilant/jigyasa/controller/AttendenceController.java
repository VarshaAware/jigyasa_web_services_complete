package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;

import com.exilant.jigyasa.vo.AttendanceRequest;
import com.exilant.jigyasa.vo.RequestStatus;
import com.exilant.jigyasa.vo.RequestTraining;

public interface AttendenceController {
	ResponseEntity<?> markAttendence(RequestStatus markAttendence) throws Exception;

	/**
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	ResponseEntity<?> fetchAttendence(AttendanceRequest reqObj) throws Exception;

	/**
	 * @param reqObj
	 * @return
	 * @throws Exception
	 */
	ResponseEntity<?> fetchAttendeeList(RequestTraining reqObj) throws Exception;
}
