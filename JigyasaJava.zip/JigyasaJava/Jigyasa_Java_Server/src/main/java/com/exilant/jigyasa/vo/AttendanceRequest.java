/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 16-May-2017
  * AttendanceRequest.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

/**
 * @author lakshmi.bhat
 *
 */
public class AttendanceRequest {
	private String date;
	private int trainingId;

	public AttendanceRequest() {
	}

	public AttendanceRequest(String date, int trainingId) {
		super();
		this.date = date;
		this.trainingId = trainingId;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date
	 *            the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the trainingId
	 */
	public int getTrainingId() {
		return trainingId;
	}

	/**
	 * @param trainingId
	 *            the trainingId to set
	 */
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AttendanceRequest [date=" + date + ", trainingId=" + trainingId + "]";
	}

}
