/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * MySqlDeleteTrainingRepositoryImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.DeleteTrainingRepository;
import com.exilant.jigyasa.vo.DeleteTraining;

/**
 * @author swathi.m
 *
 */
@Repository
public class MySqlDeleteTrainingRepositoryImpl implements DeleteTrainingRepository {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.repository.DeleteTrainingRepository#deleteTraining(
	 * com.exilant.jigyasa.vo.SuggestTraining)
	 */
	static final Logger logger = LoggerFactory.getLogger(MySqlDeleteTrainingRepositoryImpl.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int deleteTraining(DeleteTraining deleteTraining) {
		// TODO Auto-generated method stub
		try {
			String sqlSetDeleteStateForTraining = SqlQueryConstants.UPDATE_COURSES_FOR_DELETE_TRAINING;
			Object[] deleteStateForTrainingParameters = new Object[] { deleteTraining.getCourseId() };
			int result = jdbcTemplate.update(sqlSetDeleteStateForTraining, deleteStateForTrainingParameters);
			return result;
		} catch (Exception e) {
			logger.error("Deletion failed");
			return 0;
		}
	}

}
