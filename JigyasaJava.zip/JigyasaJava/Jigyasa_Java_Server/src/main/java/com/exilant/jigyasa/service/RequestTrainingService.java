package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.RequestTraining;

public interface RequestTrainingService {
	String scheduledTraining(RequestTraining scheduledTrainingRequest);
}
