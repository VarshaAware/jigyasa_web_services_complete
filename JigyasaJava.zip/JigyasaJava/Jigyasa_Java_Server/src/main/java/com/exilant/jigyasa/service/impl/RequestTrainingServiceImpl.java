package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.RequestTrainingRepository;
import com.exilant.jigyasa.service.RequestTrainingService;
import com.exilant.jigyasa.vo.RequestTraining;

@Service
public class RequestTrainingServiceImpl implements RequestTrainingService{
	@Autowired
	RequestTrainingRepository requestTrainingRepository;

	public String scheduledTraining(RequestTraining scheduledTrainingRequest) {

		return requestTrainingRepository.scheduledTraining(scheduledTrainingRequest);
	}

}
