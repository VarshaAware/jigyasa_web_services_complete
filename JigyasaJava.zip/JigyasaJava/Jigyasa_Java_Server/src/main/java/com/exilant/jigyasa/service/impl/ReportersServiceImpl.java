/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 10-May-2017
  * ReportersServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.ReportersRepository;
import com.exilant.jigyasa.service.ReportersService;
import com.exilant.jigyasa.vo.Repotees;
import com.exilant.jigyasa.vo.RequestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class ReportersServiceImpl implements ReportersService {

	@Autowired
	ReportersRepository reportersRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.service.ReportersService#getRepoters()
	 */
	@Override
	public List<Repotees> getRepoters(RequestTraining obj) {
		return reportersRepository.getListForEmployeesForManager(obj.getEmployeeId(), obj.getTrainingId());
	}

}
