/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListService.java
  *
  *******************************************************/

package com.exilant.jigyasa.service;

import java.util.List;

import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.SuggestedTraining;
import com.exilant.jigyasa.vo.TrainingList;

/**
 * @author lakshmi.bhat
 *
 */
public interface IndividualTrainingListService {

	/**
	 * @param trainingList
	 * @return
	 */
	List<MyTraining> getMyTrainingList(TrainingList trainingList);

	/**
	 * @param trainingList
	 * @return
	 */
	List<MyTraining> getTodayTrainingList(TrainingList trainingList);

	/**
	 * @param trainingList
	 * @return
	 */
	List<MyTraining> getUpcomingTrainingList(TrainingList trainingList);

	/**
	 * @param trainingList
	 * @return
	 */
	List<SuggestedTraining> getSuggestedTrainingList(TrainingList trainingList);
}
