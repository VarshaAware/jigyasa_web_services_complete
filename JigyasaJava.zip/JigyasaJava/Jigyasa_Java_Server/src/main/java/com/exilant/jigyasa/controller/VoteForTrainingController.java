package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;
import com.exilant.jigyasa.vo.TrainingList;

public interface VoteForTrainingController {
	ResponseEntity<?> VoteForTraining(TrainingList reqObj) throws Exception;
}
