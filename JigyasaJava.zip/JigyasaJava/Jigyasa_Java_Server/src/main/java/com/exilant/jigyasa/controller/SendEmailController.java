package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;
import com.exilant.jigyasa.vo.SendEmail;


public interface SendEmailController {
	ResponseEntity<?>sendEmail(SendEmail sendEmail) throws Exception;
}
