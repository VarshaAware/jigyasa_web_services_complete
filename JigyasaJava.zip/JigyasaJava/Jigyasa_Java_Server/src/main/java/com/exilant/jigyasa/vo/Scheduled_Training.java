package com.exilant.jigyasa.vo;

public class Scheduled_Training {
	private String Scheduled_Training_Id;
	private String courseId;
	private String trainingLocationId;
	private String seats;



	public Scheduled_Training() {
	}


	public Scheduled_Training(String scheduled_Training_Id, String courseId, String trainingLocationId, String seats) {
		super();
		Scheduled_Training_Id = scheduled_Training_Id;
		this.courseId = courseId;
		this.trainingLocationId = trainingLocationId;
		this.seats = seats;
	}


	/**
	 * @return the seats
	 */
	public String getSeats() {
		return seats;
	}

	/**
	 * @param seats the seats to set
	 */
	public void setSeats(String seats) {
		this.seats = seats;
	}
	public String getScheduled_Training_Id() {
		return Scheduled_Training_Id;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getTrainingLocationId() {
		return trainingLocationId;
	}

	public void setTrainingLocationId(String trainingLocationId) {
		this.trainingLocationId = trainingLocationId;
	}

	public void setScheduled_Training_Id(String scheduled_Training_Id) {
		Scheduled_Training_Id = scheduled_Training_Id;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Scheduled_Training [Scheduled_Training_Id=" + Scheduled_Training_Id + ", courseId=" + courseId
				+ ", trainingLocationId=" + trainingLocationId + ", seats=" + seats + "]";
	}

}
