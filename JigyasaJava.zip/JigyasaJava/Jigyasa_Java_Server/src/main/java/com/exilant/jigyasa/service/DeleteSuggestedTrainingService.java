package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.SuggestTraining;

public interface DeleteSuggestedTrainingService {
	Boolean deleteSuggestedTrainingService(SuggestTraining deleteSuggestedTrainingService);
}
