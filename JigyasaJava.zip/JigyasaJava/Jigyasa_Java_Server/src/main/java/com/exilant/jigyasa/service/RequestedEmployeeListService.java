package com.exilant.jigyasa.service;

import java.util.List;

import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.RequestedEmployeeList;

public interface RequestedEmployeeListService {
	List<RequestedEmployeeList> getRequestedEmployeeList(RequestTraining requestedEmployeeList);
}
