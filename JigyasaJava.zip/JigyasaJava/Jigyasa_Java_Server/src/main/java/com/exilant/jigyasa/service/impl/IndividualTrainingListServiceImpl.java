/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.IndividualTrainingListRepository;
import com.exilant.jigyasa.service.IndividualTrainingListService;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.SuggestedTraining;
import com.exilant.jigyasa.vo.TrainingList;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class IndividualTrainingListServiceImpl implements IndividualTrainingListService {
	static final Logger logger = LoggerFactory.getLogger(IndividualTrainingListServiceImpl.class);

	@Autowired
	IndividualTrainingListRepository trainingListRepository;

	TrainingListResponse result = new TrainingListResponse();

	@Override
	public List<MyTraining> getMyTrainingList(TrainingList trainingList) {
		List<MyTraining> myTrainings = null;
		if (trainingList.getEmployeeId() == 0) {
			logger.error("Employee Id is missing");
		} else if (trainingList.getDesignation() > 3 || trainingList.getDesignation() < 1) {
			logger.error("Incorrect Employee Role");
		} else {
			myTrainings = trainingListRepository.getMyTrainingList(trainingList.getEmployeeId(),
					trainingList.getDesignation());
		}

		return myTrainings;
	}

	@Override
	public List<MyTraining> getTodayTrainingList(TrainingList trainingList) {
		List<MyTraining> todayTrainings = null;
		if (trainingList.getEmployeeId() == 0) {
			logger.error("Employee Id is missing");
		} else if (trainingList.getDesignation() > 3 || trainingList.getDesignation() < 1) {
			logger.error("Incorrect Employee Role");
		} else {
			todayTrainings = trainingListRepository.getTodayTrainingList(trainingList.getEmployeeId(),
					trainingList.getDesignation());
		}
		return todayTrainings;
	}

	@Override
	public List<MyTraining> getUpcomingTrainingList(TrainingList trainingList) {
		List<MyTraining> upcomingTrainings = null;

		if (trainingList.getEmployeeId() == 0) {
			logger.error("Employee Id is missing");
		} else if (trainingList.getDesignation() > 3 || trainingList.getDesignation() < 1) {
			logger.error("Incorrect Employee Role");
		} else {
			upcomingTrainings = trainingListRepository.getUpcomingTrainingList(trainingList.getEmployeeId(),
					trainingList.getDesignation());
		}
		return upcomingTrainings;
	}

	@Override
	public List<SuggestedTraining> getSuggestedTrainingList(TrainingList trainingList) {
		List<SuggestedTraining> suggestedTrainings = null;
		if (trainingList.getEmployeeId() == 0) {
			logger.error("Employee Id is missing");
		} else if (trainingList.getDesignation() > 3 || trainingList.getDesignation() < 1) {
			logger.error("Incorrect Employee Role");
		} else {
			suggestedTrainings = trainingListRepository.getSuggestedTrainingList(trainingList.getEmployeeId(),
					trainingList.getDesignation());
		}
		return suggestedTrainings;
	}
}
