/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * CreateNewTrainingController.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;

import com.exilant.jigyasa.vo.CreateNewTraining;


/**
 * @author swathi.m
 *
 */
public interface CreateNewTrainingController {
	ResponseEntity<?> createNewTrainingHandler(CreateNewTraining createNewTraining) throws Exception;
}
