/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 09-May-2017
  * TrainerListContollerImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.TrainerListContoller;
import com.exilant.jigyasa.service.TrainerListService;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.Trainer;

/**
 * @author lakshmi.bhat
 *
 */
@RestController
public class TrainerListContollerImpl implements TrainerListContoller {

	@Autowired
	TrainerListService trainerListService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.controller.TrainerListContoller#getTrainerList(com.
	 * exilant.jigyasa.vo.Trainer)
	 */
	@Override
	@RequestMapping(value = URIConstants.TRAINER_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getTrainerList(@RequestBody(required = false) RequestTraining trainer) throws Exception {
		Map<String, List<Trainer>> map = new HashMap<String, List<Trainer>>();
		map = trainerListService.getTrainerList(trainer);
		if (map != null) {
			return new ResponseEntity<Map<String, List<Trainer>>>(map, HttpStatus.OK);
		}
		Map<String, String> mapError = new HashMap<String, String>();
		mapError.put("errorMessage", "Send proper request body");
		return new ResponseEntity<Map<String, String>>(mapError, HttpStatus.BAD_REQUEST);
	}

}
