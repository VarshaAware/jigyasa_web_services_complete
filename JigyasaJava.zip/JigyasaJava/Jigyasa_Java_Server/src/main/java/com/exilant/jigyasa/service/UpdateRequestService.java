/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 02-May-2017
  * UpdateRequestService.java
  *
  *******************************************************/

package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.RequestStatus;

/**
 * @author lakshmi.bhat
 *
 */
public interface UpdateRequestService {
	boolean updateRequestService(RequestStatus obj);
}
