package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.SendEmailController;
import com.exilant.jigyasa.service.SendEmailService;
import com.exilant.jigyasa.vo.SendEmail;

@RestController
@CrossOrigin
public class SendEmailControllerImpl implements SendEmailController {
	private Logger logger = LoggerFactory.getLogger(SendEmailController.class);

	@Autowired
	SendEmailService sendEmailService;

	@Override
	@RequestMapping(value = URIConstants.SEND_EMAIL, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> sendEmail(@RequestBody SendEmail sendEmail) throws Exception {
		try {
			boolean val = sendEmailService.sendEmail(sendEmail);
			if (val) {
				Map<String, String> map = new HashMap<>();
				map.put("status", "success");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			}
			Map<String, String> map = new HashMap<>();
			map.put("errorMessage", "someError");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Request body is not proper");
			Map<String, String> map = new HashMap<>();
			map.put("status", "Problem in fetcing request data");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
	}
}