/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 09-May-2017
  * TrainerListService.java
  *
  *******************************************************/

package com.exilant.jigyasa.service;

import java.util.List;
import java.util.Map;

import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.Trainer;

/**
 * @author lakshmi.bhat
 *
 */
public interface TrainerListService {
	Map<String, List<Trainer>> getTrainerList(RequestTraining trainer);
}
