package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.VoteForTrainingRepository;
import com.exilant.jigyasa.vo.TrainingList;

@Repository
public class MySqlVoteForTrainingRepository implements VoteForTrainingRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlVoteForTrainingRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean voteForTraining(TrainingList voteForTraining) {
		String query = SqlQueryConstants.GET_VOTE_COUNT;
		Object[] queryParameters = new Object[] { voteForTraining.getTrainingId(), voteForTraining.getEmployeeId() };
		int trainingObj = jdbcTemplate.queryForObject(query, queryParameters, (rs, rowNum) -> rs.getInt(1));

		try {
			if (trainingObj == 0) {
				String sql = SqlQueryConstants.INSERT_NEW_VOTE;
				Object[] queryParam = new Object[] { voteForTraining.getTrainingId(), voteForTraining.getEmployeeId(), 1 };
				int result = jdbcTemplate.update(sql, queryParam);

				if (result != 0) {
					String updateQuery = SqlQueryConstants.UPDATE_VOTE;
					Object[] queryPar = new Object[] { voteForTraining.getTrainingId() };

					jdbcTemplate.update(updateQuery, queryPar);
					return true;
				}

			}
		} catch (DataAccessException e) {
			logger.error("Operation failed");
			return false;
		}
		return false;

		

	}

}
