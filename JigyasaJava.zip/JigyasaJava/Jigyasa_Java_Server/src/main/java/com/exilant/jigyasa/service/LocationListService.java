package com.exilant.jigyasa.service;

import java.util.List;
import com.exilant.jigyasa.vo.TrainingLocation;

public interface LocationListService {
	List<TrainingLocation> getlocationList(TrainingLocation location);
}
