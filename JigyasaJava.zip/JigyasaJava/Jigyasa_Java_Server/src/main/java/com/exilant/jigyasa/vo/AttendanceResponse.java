/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 16-May-2017
  * AttendanceResponse.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

/**
 * @author lakshmi.bhat
 *
 */
public class AttendanceResponse {
	private String employeeName;
	private int hasAttended;
	private int employeeId;

	public AttendanceResponse() {
	}

	public AttendanceResponse(String employeeName, int hasAttended, int employeeId) {
		super();
		this.employeeName = employeeName;
		this.hasAttended = hasAttended;
		this.employeeId = employeeId;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName
	 *            the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the hasAttended
	 */
	public int getHasAttended() {
		return hasAttended;
	}

	/**
	 * @param hasAttended
	 *            the hasAttended to set
	 */
	public void setHasAttended(int hasAttended) {
		this.hasAttended = hasAttended;
	}

	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId
	 *            the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AttendanceResponse [employeeName=" + employeeName + ", hasAttended=" + hasAttended + ", employeeId="
				+ employeeId + "]";
	}

}
