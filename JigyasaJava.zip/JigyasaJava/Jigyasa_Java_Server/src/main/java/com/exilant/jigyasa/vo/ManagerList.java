/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * ManagerList.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

/**
 * @author swathi.m
 *
 */
public class ManagerList {
private String name;
private int empId;
public ManagerList() {
	super();
}
public ManagerList(String name, int empId) {
	super();
	this.name = name;
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
@Override
public String toString() {
	return "ManagerList [name=" + name + ", empId=" + empId + "]";
}


}
