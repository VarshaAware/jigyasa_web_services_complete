/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * DeleteTrainingControllerImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.DeleteTrainingController;
import com.exilant.jigyasa.service.DeleteTrainingService;
import com.exilant.jigyasa.vo.DeleteTraining;

/**
 * @author swathi.m
 *
 */
@RestController
public class DeleteTrainingControllerImpl implements DeleteTrainingController {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.controller.DeleteTrainingController#deleteTraining(
	 * com.exilant.jigyasa.vo.SuggestedTraining)
	 */
	static final Logger logger = LoggerFactory.getLogger(DeleteTrainingControllerImpl.class);
	@Autowired
	DeleteTrainingService deleteTrainingService;

	@Override
	@RequestMapping(value = URIConstants.DELETE_TRAINING, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> deleteTraining(@RequestBody DeleteTraining deleteTraining) throws Exception {
		// TODO Auto-generated method stub

		try {
			int val = deleteTrainingService.deleteTrainingService(deleteTraining);
			if (val != 0) {
				Map<String, String> map = new HashMap<>();
				map.put("status", "deletion success");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			} else {
				Map<String, String> map = new HashMap<>();
				map.put("status", "deletion failed");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			}
		} catch (Exception e) {
			logger.error("Request body is not proper");
			Map<String, String> map = new HashMap<>();
			map.put("status", "Problem in fetcing request data");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}

	}

}
