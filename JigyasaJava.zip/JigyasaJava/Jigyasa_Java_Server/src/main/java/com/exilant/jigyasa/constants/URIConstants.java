/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 27-Apr-2017
  * URIConstants.java
  *
  *******************************************************/

package com.exilant.jigyasa.constants;

/**
 * @author lakshmi.bhat
 *
 */
public class URIConstants {
	public static final String LOGIN = "/Jigyasa/Login";
	public static final String REQUEST_TRAINING = "/Jigyasa/RequestManagerToNominateForTraining";
	public static final String SUGGEST_TRAINING = "/Jigyasa/SuggestTraining";
	public static final String NOMINATE_TRAINING = "/Jigyasa/NominateTraining";
	public static final String UPDATE_SUGGEST_TRAINING_STATUS="/Jigyasa/UpdateSuggestionStatus";
	public static final String UPDATE_REQUEST_STATUS = "/Jigyasa/UpdateRequestStatus";
	public static final String CREATE_NEW_TRAINING = "/Jigyasa/CreateTraining";
	public static final String VOTE_FOR_TRAINING="/Jigyasa/VoteForTraining";
	public static final String LOCATION_LIST="/Jigyasa/LocationList";
	public static final String  REQUEST_EMPLOYEE_LIST ="/Jigyasa/RequestedEmployeeList";
	public static final String SUGGEST_TRAINING_LIST="/Jigyasa/SuggestedTrainingList";
	public static final String MARK_ATTENDENCE="/Jigyasa/MarkAttendence";
	public static final String DELETE_SUGGESTED_TRAINING="/Jigyasa/DeleteSuggestedTraining";
	public static final String SEND_EMAIL="/Jigyasa/SendEmail";
	public static final String TRAINING_LIST = "/Jigyasa/TrainingList";
	public static final String TRAINING_DETAILS = "/Jigyasa/TrainingDetails";
	public static final String HISTORY = "/Jigyasa/History";
	public static final String TRAINER_LIST = "/Jigyasa/TrainerList";
	public static final String SELF_DECLINE_NOMINATION = "/Jigyasa/SelfDeclineNominatedTrainingHandler";
	public static final String REPORTERS = "/Jigyasa/Reporters";
	public static final String FETCH_ATTENDENCE="/Jigyasa/FetchAttendance";
	public static final String MY_TRAINING_LIST = "/Jigyasa/MyTrainingList";
	public static final String TODAY_TRAINING_LIST = "/Jigyasa/TodayTrainingList";
	public static final String UPCOMING_TRAINING_LIST = "/Jigyasa/UpcomingTrainingList";
	public static final String SUGGESTED_TRAINING_LIST = "/Jigyasa/SuggestedTrainingList";
	public static final String FETCH_DETAILS_FOR_EDIT = "/Jigyasa/FetchDetailsForEdit";
	public static final String GET_MANAGER_LIST = "/Jigyasa/ManagerList";
	public static final String DELETE_TRAINING = "/Jigyasa/DeleteTraining";
	public static final String FETCH_ATTENDEES = "/Jigyasa/AttendeesList";
}
