package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.SendEmail;

public interface SendEmailRepository {
	boolean sendEmail(SendEmail sendEmail);
}
