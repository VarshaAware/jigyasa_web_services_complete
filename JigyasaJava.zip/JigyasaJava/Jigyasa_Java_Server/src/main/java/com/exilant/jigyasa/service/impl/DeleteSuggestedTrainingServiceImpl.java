package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.DeleteSuggestedTrainingRepository;
import com.exilant.jigyasa.service.DeleteSuggestedTrainingService;
import com.exilant.jigyasa.vo.SuggestTraining;

@Service
public class DeleteSuggestedTrainingServiceImpl implements DeleteSuggestedTrainingService{
	@Autowired
	DeleteSuggestedTrainingRepository deleteSuggestedTrainingRepository;

	

	@Override
	public Boolean deleteSuggestedTrainingService(SuggestTraining deleteSuggestedTrainingService) {
		return deleteSuggestedTrainingRepository.deleteSuggestedTraining(deleteSuggestedTrainingService);
	}
}
