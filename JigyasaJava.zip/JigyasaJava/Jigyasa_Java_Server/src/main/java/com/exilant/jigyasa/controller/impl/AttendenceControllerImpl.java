package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.AttendenceController;
import com.exilant.jigyasa.service.AttendenceService;
import com.exilant.jigyasa.vo.AttendanceRequest;
import com.exilant.jigyasa.vo.AttendanceResponse;
import com.exilant.jigyasa.vo.Attendees;
import com.exilant.jigyasa.vo.RequestStatus;
import com.exilant.jigyasa.vo.RequestTraining;

@RestController
public class AttendenceControllerImpl implements AttendenceController {
	static final Logger logger = LoggerFactory.getLogger(NominateForTrainingControllerImpl.class);

	@Autowired
	AttendenceService attendenceService;

	@Override
	@RequestMapping(value = URIConstants.MARK_ATTENDENCE, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> markAttendence(@RequestBody RequestStatus markAttendence) throws Exception {
		try {
			boolean val = attendenceService.markAttendence(markAttendence);
			Map<String, String> map = new HashMap<>();
			if (val) {
				map.put("status", "success");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			}
			map.put("errorMessage", "someError");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Request body is not proper: Send nomineeId as list");
			Map<String, String> map = new HashMap<>();
			map.put("status", "Problem in fetcing request data");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
	}
	
	@Override
	@RequestMapping(value = URIConstants.FETCH_ATTENDENCE, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> fetchAttendence(@RequestBody AttendanceRequest reqObj) throws Exception {
		List<AttendanceResponse> attendees = attendenceService.fetchAttendence(reqObj);
		if(attendees != null){
			Map<String,List<AttendanceResponse>> map = new HashMap<>();
			map.put("attendees", attendees);
			return new ResponseEntity<Map<String,List<AttendanceResponse>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<>();
		map.put("status", "Problem in fetcing request data");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
	}
	
	@Override
	@RequestMapping(value = URIConstants.FETCH_ATTENDEES, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> fetchAttendeeList(@RequestBody RequestTraining reqObj) throws Exception {
		List<Attendees> attendees = attendenceService.fetchAttendeeList(reqObj);
		if(attendees != null){
			Map<String,List<Attendees>> map = new HashMap<>();
			map.put("attendees", attendees);
			return new ResponseEntity<Map<String,List<Attendees>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<>();
		map.put("status", "Problem in fetcing request data");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
	}
}