package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.DeleteSuggestedTrainingRepository;
import com.exilant.jigyasa.vo.SuggestTraining;

@Repository
public class MySqlDeleteSuggestedTrainingReopsitory implements DeleteSuggestedTrainingRepository{

	static final Logger logger = LoggerFactory.getLogger(MySqlUpdateSuggestionTrainingStatus.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Override
	public boolean deleteSuggestedTraining(SuggestTraining deleteSuggestedTraining) {
		try {
			String sql = SqlQueryConstants.DELETE_SUGGESTED_TRAINING;
			Object[] queryParameters = null;
			queryParameters = new Object[] { deleteSuggestedTraining.getTrainingId(),deleteSuggestedTraining.getTrainingId() };
			jdbcTemplate.update(sql, queryParameters);
			return true;
		} catch (Exception e) {
			logger.error("Updation failed");
			return false;
		}

	}

}
