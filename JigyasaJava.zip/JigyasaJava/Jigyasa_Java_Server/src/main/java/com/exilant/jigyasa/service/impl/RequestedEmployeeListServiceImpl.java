package com.exilant.jigyasa.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.RequestedEmployeeListRepository;
import com.exilant.jigyasa.service.RequestedEmployeeListService;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.RequestedEmployeeList;

@Service
public class RequestedEmployeeListServiceImpl implements RequestedEmployeeListService {

	@Autowired
	RequestedEmployeeListRepository requestedEmployeeListRepository;

	@Override
	public List<RequestedEmployeeList> getRequestedEmployeeList(RequestTraining requestedEmployeeList) {
		List<RequestedEmployeeList> requestedEmpList = new ArrayList<RequestedEmployeeList>();

		requestedEmpList = requestedEmployeeListRepository
				.getRequestedEmployeeList(requestedEmployeeList.getEmployeeId(), requestedEmployeeList.getTrainingId());

		return requestedEmpList;
	}

}
