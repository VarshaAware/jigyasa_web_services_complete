/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * CreateNewTrainingRepositoryImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository.impl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.CreateNewTrainingRepository;
import com.exilant.jigyasa.vo.CreateNewTraining;
import com.exilant.jigyasa.vo.Schedule;
import com.exilant.jigyasa.vo.Trainer;
import com.exilant.jigyasa.vo.TrainerList;

/**
 * @author swathi.m
 *
 */
@Repository
public class CreateNewTrainingRepositoryImpl implements CreateNewTrainingRepository {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.repository.CreateNewTrainingRepository#
	 * createNewTraining(com.exilant.jigyasa.vo.CreateNewTraining)
	 */
	static final Logger logger = LoggerFactory.getLogger(CreateNewTrainingRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int createNewTraining(CreateNewTraining createNewTraining) {
		// TODO Auto-generated method stub
		int trainingId = 0;
		try {
			// Employee emp = new Employee();
			String imageName = decodeImage(createNewTraining.getTraining().getImage(),
					createNewTraining.getTraining().getTitle());

			String sqlCourses = SqlQueryConstants.INSERT_COURSES;
			// System.out.println(imageName);
			Object[] queryParameters = new Object[] { createNewTraining.getTraining().getTitle(), imageName,
					createNewTraining.getTraining().getDescription(), createNewTraining.getTraining().getLink(),
					createNewTraining.getStatus() };

			int result = jdbcTemplate.update(sqlCourses, queryParameters);
			if (result != 0) {
				String sqlCourseId = SqlQueryConstants.GET_COURSE_ID;
				int courseId = jdbcTemplate.queryForObject(sqlCourseId, Integer.class);

				int trainingLocationId = 0;
				for (Schedule schedule : createNewTraining.getSchedule()) {
					String sqlTrainingLocationId = SqlQueryConstants.GET_TRAINING_LOCATION_ID;
					System.out.println(schedule.getLocation());
					trainingLocationId = jdbcTemplate.queryForObject(sqlTrainingLocationId, Integer.class,
							schedule.getLocation());
					System.out.println(trainingLocationId);

				}

				for (TrainerList trainerList : createNewTraining.getTrainerList()) {
					String sqlTrainerCheck = SqlQueryConstants.NO_OF_TRAINERS;

					int trainerCheck = jdbcTemplate.queryForObject(sqlTrainerCheck, Integer.class,
							trainerList.getEmployeeId());
					List<Trainer> employees = null;
					if (trainerCheck == 0) {
						for (TrainerList employeeList : createNewTraining.getTrainerList()) {
							String sqlCheckEmployee = SqlQueryConstants.GET_EMPLOYEE_NAME;
							Object[] employeeDetails = new Object[] { employeeList.getEmployeeId() };
							employees = jdbcTemplate.query(sqlCheckEmployee, employeeDetails, (rs, rows) -> {
								Trainer emp = new Trainer();
								emp.setEmployeeId(rs.getInt(1) + "");
								emp.setEmployeeName(rs.getString(2));
								return emp;
							});
						}
						for (Trainer employee : employees) {
							String sqlInsertTrainer = SqlQueryConstants.INSERT_TRAINERS_ID_NAME;
							Object[] insertTrainer = new Object[] { employee.getEmployeeId(),
									employee.getEmployeeName() };
							jdbcTemplate.update(sqlInsertTrainer, insertTrainer);
						}
					}
				}

				String sqlscheduledTraining = SqlQueryConstants.INSERT_SCHEDULED_TRAINING;
				Object[] scheduledTrainingQueryParameters = new Object[] { courseId,trainingLocationId ,
						createNewTraining.getTraining().getSeats() };
				int resultScheduledTraining = jdbcTemplate.update(sqlscheduledTraining,
						scheduledTrainingQueryParameters);

				if (resultScheduledTraining != 0) {
					String sqlTrainingId = SqlQueryConstants.GET_SCHEDULED_TRAINING_ID;
					trainingId = jdbcTemplate.queryForObject(sqlTrainingId, Integer.class);

					for (TrainerList trainersList : createNewTraining.getTrainerList()) {
						String sqlInsertTrainingId = SqlQueryConstants.INSERT_TRAINERS_NOMINATED_FOR_TRAINING;
						Object[] insertTrainingId = new Object[] { trainingId, trainersList.getEmployeeId() };
						jdbcTemplate.update(sqlInsertTrainingId, insertTrainingId);
					}

					String sqlInsertManagers = SqlQueryConstants.INSERT_MANAGERS_NOMINATED_FOR_TRAINING;
					for (String cclist : createNewTraining.getNotification().getCcListId()) {
						Object[] inserManagers = new Object[] { trainingId, Integer.parseInt(cclist) };
						jdbcTemplate.update(sqlInsertManagers, inserManagers);
					}

				}

				Schedule schedule = createNewTraining.getSchedule().get(0);
				String sqlScheduleTime = SqlQueryConstants.INSERT_SCHEDULED_TRAINING_TIME;
				Object[] scheduleTimeQueryParameters = new Object[] { trainingId, schedule.getStartDate(),
						schedule.getEndDate() };
				jdbcTemplate.update(sqlScheduleTime, scheduleTimeQueryParameters);

//				for (TrainerList trainerlist : createNewTraining.getTrainerList()) {
//					String sqlTrainers = SqlQueryConstants.INSERT_TRAINERS;
//					Object[] trainerQueryParameters = new Object[] { trainerlist.getEmployeeId() };
//					jdbcTemplate.update(sqlTrainers, trainerQueryParameters);
//				}

				String sqlNotification = SqlQueryConstants.INSERT_TRAINING_NOTIFICATIONS;
				Object[] notificationQueryParameters = new Object[] { trainingId,
						createNewTraining.getNotification().getType(), createNewTraining.getNotification().getSubject(),
						createNewTraining.getNotification().getContent(),
						createNewTraining.getNotification().getRcpType() };
				jdbcTemplate.update(sqlNotification, notificationQueryParameters);
			}
			return trainingId;
		} catch (Exception e) {
			logger.error("New Training not created  " + e.getMessage());
			return 0;
		}

	}

	private String decodeImage(String imageName, String courseName) {
		String s = System.getProperty("user.dir");
		String path = s + "/Images/" + courseName;
		File folder2 = new File(path);
		System.out.println(folder2);
		Decoder en = Base64.getDecoder();
		String rectifiedString = imageName.replace("\\", "");
		if (!folder2.exists()) {
			String serverPath = s + "/Images/";
			folder2 = new File(serverPath);
		}
		// String rectifiedString = imageName.replaceAll("\\s+","");
		byte[] bytes1 = en.decode(rectifiedString);
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes1);
		BufferedImage image = null;

		try {
			image = ImageIO.read(bis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(image);
		try {
			ImageIO.write(image, "png", folder2);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return path;
	}

}
