/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * CreateNewTraining.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

import java.util.List;

import javax.validation.Valid;

/**
 * @author swathi.m
 *
 */
public class CreateNewTraining {
	@Valid
private Training training;
private List<Schedule> schedule;
private List<TrainerList> trainerList;
private Notification notification;
private String status;
public CreateNewTraining() {
	super();
}
public CreateNewTraining(Training training, List<Schedule> schedule, List<TrainerList> trainerList,
		Notification notification, String status) {
	super();
	this.training = training;
	this.schedule = schedule;
	this.trainerList = trainerList;
	this.notification = notification;
	this.status = status;
}
public Training getTraining() {
	return training;
}
public void setTraining(Training training) {
	this.training = training;
}
public List<Schedule> getSchedule() {
	return schedule;
}
public void setSchedule(List<Schedule> schedule) {
	this.schedule = schedule;
}
public List<TrainerList> getTrainerList() {
	return trainerList;
}
public void setTrainerList(List<TrainerList> trainerList) {
	this.trainerList = trainerList;
}
public Notification getNotification() {
	return notification;
}
public void setNotification(Notification notification) {
	this.notification = notification;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "CreateNewTraining [training=" + training + ", schedule=" + schedule + ", trainerList=" + trainerList
			+ ", notification=" + notification + ", status=" + status + "]";
}




}