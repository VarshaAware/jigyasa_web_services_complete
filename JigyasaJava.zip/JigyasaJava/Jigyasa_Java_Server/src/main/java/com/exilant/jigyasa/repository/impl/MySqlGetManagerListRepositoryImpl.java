/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * MySqlGetManagerListRepositoryImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.GetManagerListRepository;
import com.exilant.jigyasa.vo.ManagerList;

/**
 * @author swathi.m
 *
 */
@Repository
public class MySqlGetManagerListRepositoryImpl implements GetManagerListRepository {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.repository.GetManagerListRepository#getManagerList()
	 */

	static final Logger logger = LoggerFactory.getLogger(CreateNewTrainingRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<ManagerList> getManagerList() {
		// TODO Auto-generated method stub
		try {

			String sqlGetManagers = SqlQueryConstants.GET_EMPLOYEES;
			List<ManagerList> managerslist = jdbcTemplate.query(sqlGetManagers, (rs, rowNum) -> {
				ManagerList managerList = new ManagerList();
				managerList.setName(rs.getString(2));
				managerList.setEmpId(rs.getInt(1));
				return managerList;
			});
			return managerslist;
		} catch (Exception e) {
			logger.error("Manager List not found ");
			return null;
		}
	}
}
