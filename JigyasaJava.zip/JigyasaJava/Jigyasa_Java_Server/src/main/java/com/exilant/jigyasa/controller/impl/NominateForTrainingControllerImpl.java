/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * NominateForTrainingImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.NominateForTrainingController;
import com.exilant.jigyasa.service.NominateForTrainingService;
import com.exilant.jigyasa.vo.ScheduledTrainingNominee;
import com.exilant.jigyasa.vo.SuggestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@RestController
public class NominateForTrainingControllerImpl implements NominateForTrainingController {
	static final Logger logger = LoggerFactory.getLogger(NominateForTrainingControllerImpl.class);

	@Autowired
	NominateForTrainingService nominateForTrainingService;

	@Override
	@RequestMapping(value = URIConstants.NOMINATE_TRAINING, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> nominateEmp(@RequestBody ScheduledTrainingNominee nominee) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			List<?> requestedList = nominateForTrainingService.nominateEmp(nominee);
			if (requestedList.isEmpty()) {
				map.put("status", "success");
				return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
			} else if (requestedList.get(0).equals("some error")) {
				map.put("errorMessage", "failed");
				return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
			}
			map.put("status", "unsuccess");
			map.put("requestedList", requestedList);
			return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Request body is not proper: Send nomineeId as list"+e);
			map.put("status", "Problem in fetcing request data");
			return new ResponseEntity<Map<String, Object>>(map, HttpStatus.OK);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.controller.NominateForTrainingController#
	 * selfDeclineNomination(com.exilant.jigyasa.vo.SuggestedTraining)
	 */
	@Override
	@RequestMapping(value = URIConstants.SELF_DECLINE_NOMINATION, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> selfDeclineNomination(@RequestBody SuggestTraining trainingObj) throws Exception {
		boolean isUpdated = nominateForTrainingService.selfDeclineNomination(trainingObj);
		Map<String, String> map = new HashMap<>();
		if (isUpdated) {
			map.put("status", "success");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
		map.put("status", "No scheduled training found to decline");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
	}
}
