package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.RequestedEmployeeListRepository;
import com.exilant.jigyasa.vo.RequestedEmployeeList;

@Repository
public class MySqlRequestedEmployeeListRepository implements RequestedEmployeeListRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<RequestedEmployeeList> getRequestedEmployeeList(int employeeId, int trainingId) {
		try {
			String sql = SqlQueryConstants.GET_SCHEDULED_TRAINING_REQUEST_DETAILS;
			List<RequestedEmployeeList> trainerList = jdbcTemplate.query(sql, new Object[] { employeeId, trainingId },
					(rs, rowNum) -> {
						RequestedEmployeeList requestedEmp = new RequestedEmployeeList();
						requestedEmp.setTrainingId("" + rs.getInt(1));
						requestedEmp.setEmployeeId("" + rs.getInt(2));
						requestedEmp.setTraining_requestor_ManagerId("" + rs.getInt(4));
						requestedEmp.setTraining_requestor_Name(rs.getString(3));
						requestedEmp.setStatus(rs.getString(5));
						requestedEmp.setCreated_By("false");
						requestedEmp.setCreated_Date("false");
						requestedEmp.setModified_By("false");
						requestedEmp.setModified_Date("false");
						requestedEmp.setRequest_Id("" + rs.getInt(10));

						return requestedEmp;
					});
			return trainerList;
		} catch (Exception e) {
			return null;
		}
	}

}
