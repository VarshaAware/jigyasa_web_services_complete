package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.SuggestTrainingRepository;
import com.exilant.jigyasa.service.SuggestTrainingService;
import com.exilant.jigyasa.vo.SuggestTraining;

@Service
public class SuggestTrainingServiceImpl implements SuggestTrainingService{
	@Autowired
	SuggestTrainingRepository suggestTrainingRepository;

	public Boolean suggestTraining(SuggestTraining suggestTrainingRequest)
	{
		return suggestTrainingRepository.suggestTraining(suggestTrainingRequest);
	}


}