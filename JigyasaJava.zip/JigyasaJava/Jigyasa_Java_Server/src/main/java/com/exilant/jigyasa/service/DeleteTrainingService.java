/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * DeleteTrainingService.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.DeleteTraining;

/**
 * @author swathi.m
 *
 */
public interface DeleteTrainingService {
	int deleteTrainingService(DeleteTraining deleteTraining);
}
