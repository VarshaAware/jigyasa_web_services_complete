/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 09-May-2017
  * RequestStatus.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import java.util.List;

/**
 * @author lakshmi.bhat
 *
 */
public class RequestStatus {
	private List<Integer> employeeId;
	private int trainingId;
	private String startDate;
	private String status;

	public RequestStatus() {
	}

	public RequestStatus(List<Integer> employeeId, int trainingId, String startDate, String status) {
		super();
		this.employeeId = employeeId;
		this.trainingId = trainingId;
		this.startDate = startDate;
		this.status = status;
	}

	/**
	 * @return the employeeId
	 */

	public List<Integer> getEmployeeId() {
		return employeeId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @param employeeId
	 *            the employeeId to set
	 */
	public void setEmployeeId(List<Integer> employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the trainingId
	 */
	public int getTrainingId() {
		return trainingId;
	}

	/**
	 * @param trainingId
	 *            the trainingId to set
	 */
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "RequestStatus [employeeId=" + employeeId + ", trainingId=" + trainingId + ", startDate=" + startDate
				+ ", status=" + status + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */

}
