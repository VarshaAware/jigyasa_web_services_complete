/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * GetManagerListService.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service;

import java.util.List;

import com.exilant.jigyasa.vo.ManagerList;

/**
 * @author swathi.m
 *
 */
public interface GetManagerListService {
	List<ManagerList> getManagerList(ManagerList managerList);
}
