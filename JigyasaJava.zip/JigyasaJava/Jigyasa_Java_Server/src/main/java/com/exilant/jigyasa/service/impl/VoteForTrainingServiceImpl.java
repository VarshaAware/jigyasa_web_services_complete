package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.exilant.jigyasa.repository.VoteForTrainingRepository;
import com.exilant.jigyasa.service.VoteForTrainingService;
import com.exilant.jigyasa.vo.TrainingList;

@Service
public class VoteForTrainingServiceImpl implements VoteForTrainingService{

	@Autowired
	VoteForTrainingRepository voteForTrainingRepository;
	
	@Override
	public Boolean voteForTraining(TrainingList voteForTraining) {
		
		return voteForTrainingRepository.voteForTraining(voteForTraining);
	}



}
