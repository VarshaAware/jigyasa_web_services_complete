package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.LocationListRepository;
import com.exilant.jigyasa.vo.TrainingLocation;

@Repository
public class MySqlLocationListRepository implements LocationListRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlLocationListRepository.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<TrainingLocation> getLocationList() {
		try {
			String sql = SqlQueryConstants.GET_LOCATION_LIST;
			List<TrainingLocation> locationList = jdbcTemplate.query(sql, (rs, rowNum) -> {
				TrainingLocation location = new TrainingLocation();
				location.setLocationId("" + rs.getInt(1));
				location.setLocation(rs.getString(2));
				return location;
			});
			return locationList;
		} catch (Exception e) {
			logger.error("Selection failed");
			return null;
		}
	}

}
