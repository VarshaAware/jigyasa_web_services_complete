package com.exilant.jigyasa.repository;

import java.util.List;

import com.exilant.jigyasa.vo.TrainingLocation;

public interface LocationListRepository {
	List<TrainingLocation> getLocationList();

	
}
