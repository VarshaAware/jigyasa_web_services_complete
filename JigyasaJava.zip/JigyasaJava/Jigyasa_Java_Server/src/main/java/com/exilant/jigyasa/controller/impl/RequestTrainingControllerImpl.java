package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.RequestTrainingController;
import com.exilant.jigyasa.service.RequestTrainingService;
import com.exilant.jigyasa.vo.RequestTraining;

@RestController
@CrossOrigin
public class RequestTrainingControllerImpl implements RequestTrainingController {
	static final Logger logger = LoggerFactory.getLogger(RequestTrainingControllerImpl.class);

	@Autowired
	RequestTrainingService requestTrainingService;

	@Override
	@RequestMapping(value = URIConstants.REQUEST_TRAINING, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> RequestManagerToNominateForTraining(@RequestBody RequestTraining reqObj) throws Exception {
		try {
			String val = requestTrainingService.scheduledTraining(reqObj);
			// if its new request it will be inserted into db
			if (val == "inserted") {
				Map<String, String> map = new HashMap<>();
				map.put("status", "success");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);

			}
			// If trainingId is not valid
			else if (val == "Selectionoftrainingfailed") {
				Map<String, String> map = new HashMap<>();
				map.put("status", "Invalid Training ID " + reqObj.getTrainingId());
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			}
			// If the request already exits
			else {
				Map<String, String> map = new HashMap<>();
				map.put("errorMessage", "someError");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			}

		} catch (Exception e) {
			logger.error("Request body is not proper: Send nomineeId as list");
			Map<String, String> map = new HashMap<>();
			map.put("status", "Problem in fetcing request data");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
	}
}