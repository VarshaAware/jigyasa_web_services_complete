package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.AttendenceRepository;
import com.exilant.jigyasa.vo.AttendanceResponse;
import com.exilant.jigyasa.vo.Attendees;
import com.exilant.jigyasa.vo.RequestStatus;

@Repository
public class MySqlAttendenceRepository implements AttendenceRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlAttendenceRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean markAttendence(RequestStatus markAttendence) {
		try {

			for (Integer i : markAttendence.getEmployeeId()) {
				String sql = SqlQueryConstants.INSERT_MARK_ATTENDENCE;
				Object[] queryParameters = new Object[] { markAttendence.getTrainingId(), i.intValue(),
						markAttendence.getStartDate() };
				jdbcTemplate.update(sql, queryParameters);
			}
			return true;
		} catch (Exception e) {
			logger.error("Insertion failed");
			return false;
		}
	}

	@Override
	public List<AttendanceResponse> fetchAttendence(int trainingId, String date) {
		try {
			String nominated = "Nominated";
			String approved = "Approved";
			String query = SqlQueryConstants.GET_ATTENDANCE;
			Object[] params = new Object[] { trainingId, nominated, trainingId, approved, trainingId, date };
			List<AttendanceResponse> responses = jdbcTemplate.query(query, params, (rs, rows) -> {
				AttendanceResponse responseObj = new AttendanceResponse();
				responseObj.setEmployeeId(rs.getInt(1));
				responseObj.setEmployeeName(rs.getString(2));
				responseObj.setHasAttended(rs.getInt(3));
				return responseObj;
			});
			return responses;
		} catch (Exception e) {
			return null;
		}
	}
	
	@Override
	public List<Attendees> fetchAttendeeList(int employeeId, int trainingId) {
		try {
			String nominated = "Nominated";
			String approved = "Approved";
			String query = SqlQueryConstants.GET_ATTENDEES;
			Object[] params = new Object[] { trainingId, nominated, employeeId, trainingId, approved, employeeId};
			List<Attendees> responses = jdbcTemplate.query(query, params, (rs, rows) -> {
				Attendees responseObj = new Attendees();
				responseObj.setEmpId(rs.getInt(1)+"");
				responseObj.setName(rs.getString(2));
				return responseObj;
			});
			return responses;
		} catch (Exception e) {
			return null;
		}
	}
}