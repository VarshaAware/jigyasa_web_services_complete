/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 03-May-2017
>  * MySQLUpdateTrainingRepositryImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.UpdateTrainingRepository;
import com.exilant.jigyasa.vo.CreateNewTraining;
import com.exilant.jigyasa.vo.TrainerList;

/**
 * @author swathi.m
 *
 */
@Repository
public class MySQLUpdateTrainingRepositryImpl implements UpdateTrainingRepository {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.repository.UpdateTrainingRepository#updateTraining(
	 * com.exilant.jigyasa.vo.CreateNewTraining)
	 */

	static final Logger logger = LoggerFactory.getLogger(MySQLUpdateTrainingRepositryImpl.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int updateTraining(CreateNewTraining updateTraining) {
		// TODO Auto-generated method stub

		try {
			String sqlCourses = SqlQueryConstants.GET_COURSEID;

			System.out.println(sqlCourses);
			int courseId = 0;

			System.out.println(updateTraining.getTraining().getTrainingId());
			courseId = jdbcTemplate.queryForObject(sqlCourses, Integer.class,
					updateTraining.getTraining().getTrainingId());

			int result = 0;

			String sqlTraining = SqlQueryConstants.UPDATE_COURSES;
			System.out.println(courseId);
			Object[] queryParameters = new Object[] { updateTraining.getTraining().getTitle(),
					updateTraining.getTraining().getDescription(), updateTraining.getTraining().getLink(),
					updateTraining.getTraining().getImage(), updateTraining.getStatus(), courseId };

			result = jdbcTemplate.update(sqlTraining, queryParameters);

			if (result != 0) {
				int trainingLocationId = 0;
				// for (Schedule schedule : updateTraining.getSchedule()) {
				String sqlTrainingLocationId = SqlQueryConstants.GET_TRAINING_LOCATION_ID;
				trainingLocationId = jdbcTemplate.queryForObject(sqlTrainingLocationId, Integer.class,
						updateTraining.getSchedule().get(0).getLocation());
				// }

				int resultOne = 0;

				String sqlEditTraining = SqlQueryConstants.UPDATE_SCHEDULED_TRAINING;
				Object[] scheduledEditTrainingParameters = new Object[] { trainingLocationId,
						updateTraining.getTraining().getSeats(), updateTraining.getTraining().getTrainingId() };

				System.out.println("///////////////////////////////" + updateTraining.getTraining().getTrainingId());

				resultOne = jdbcTemplate.update(sqlEditTraining, scheduledEditTrainingParameters);

				int resultTwo = 0;
				if (resultOne != 0) {

					// for (Schedule schedule : updateTraining.getSchedule()) {
					String sqlEditTrainingTime = SqlQueryConstants.UPDATE_SCHEDULED_TRAINING_TIME;
					Object[] scheduledEditTrainingTimeParameters = new Object[] {
							updateTraining.getSchedule().get(0).getStartDate(),
							updateTraining.getSchedule().get(0).getEndDate(),
							updateTraining.getTraining().getTrainingId() };
					resultTwo = jdbcTemplate.update(sqlEditTrainingTime, scheduledEditTrainingTimeParameters);
					// }

					int resultThree = 0;
					if (resultTwo != 0) {

						String sqlEditNotification = SqlQueryConstants.UPDATE_TRAINING_NOTIFICATIONS;
						Object[] scheduledEditNotificationParameters = new Object[] {
								updateTraining.getNotification().getType(),
								updateTraining.getNotification().getSubject(),
								updateTraining.getNotification().getContent(),
								updateTraining.getTraining().getTrainingId() };
						resultThree = jdbcTemplate.update(sqlEditNotification, scheduledEditNotificationParameters);

						if (resultThree != 0) {

							// for (TrainerList trainerlist :
							// updateTraining.getTrainerList()) {
							String sqlDeleteTrainers = SqlQueryConstants.DELETE_TRAINERS_NOMINATED_FOR_TRAINING;
							Object[] deleteTrainers = new Object[] { updateTraining.getTraining().getTrainingId() };
							jdbcTemplate.update(sqlDeleteTrainers, deleteTrainers);
							// }
							int trainerCheck = 0;
							String trainersName = null;
							for (TrainerList trainerlist : updateTraining.getTrainerList()) {
								String sqlTrainerCheck = "Select count(*) from Trainers where Trainer_id = ?";
								trainerCheck = jdbcTemplate.queryForObject(sqlTrainerCheck, Integer.class,
										trainerlist.getEmployeeId());
								if (trainerCheck == 1) {
									continue;
								}

								else {
									for (TrainerList trainerslist : updateTraining.getTrainerList()) {
										List<TrainerList> trainers = null;
										String sqlForTrainerName = "select Employee_Name from Employees where Employee_Id = ?";
										Object[] trainerName = new Object[] { trainerslist.getEmployeeId() };
										trainersName = jdbcTemplate.queryForObject(sqlForTrainerName, String.class,
												trainerName);
										String sqlInsertTrainer = "INSERT INTO Trainers (Trainer_Id, Trainer_Name) VALUES (?, ? );";
										Object[] insertTrainer = new Object[] { trainerslist.getEmployeeId(),
												trainersName };
										jdbcTemplate.update(sqlInsertTrainer, insertTrainer);

									}
								}
							}

							for (TrainerList trainerlist : updateTraining.getTrainerList()) {
								String sqlInsertTrainers = SqlQueryConstants.INSERT_TRAINERS_NOMINATED_FOR_TRAINING;
								Object[] insertTrainers = new Object[] { updateTraining.getTraining().getTrainingId(),
										trainerlist.getEmployeeId() };
								jdbcTemplate.update(sqlInsertTrainers, insertTrainers);
							}

							String sqlDeleteManager = SqlQueryConstants.DELETE_MANAGERS_NOMINATED_FOR_TRAINING;
							Object[] deleteManager = new Object[] { updateTraining.getTraining().getTrainingId() };
							jdbcTemplate.update(sqlDeleteManager, deleteManager);
							for (String managerId : updateTraining.getNotification().getCcListId()) {
								String sqlInsertManagers = SqlQueryConstants.INSERT_MANAGERS_NOMINATED_FOR_TRAINING;
								Object[] insertManagers = new Object[] { updateTraining.getTraining().getTrainingId(),
										managerId };
								jdbcTemplate.update(sqlInsertManagers, insertManagers);
							}
							return updateTraining.getTraining().getTrainingId();
						}

					}
				}
			}
		} catch (EmptyResultDataAccessException e) {
			logger.error("Error in update training" + e.getMessage());
			return 0;
		}
		return 0;

	}

}
