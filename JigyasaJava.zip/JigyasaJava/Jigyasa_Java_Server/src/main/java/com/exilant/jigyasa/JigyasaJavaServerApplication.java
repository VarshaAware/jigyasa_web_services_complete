package com.exilant.jigyasa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JigyasaJavaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JigyasaJavaServerApplication.class, args);
	}
}
