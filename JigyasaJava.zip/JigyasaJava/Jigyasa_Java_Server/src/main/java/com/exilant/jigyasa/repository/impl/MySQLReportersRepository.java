/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 10-May-2017
  * MySQLReportersRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.ReportersRepository;
import com.exilant.jigyasa.vo.Repotees;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLReportersRepository implements ReportersRepository {
	static final Logger logger = LoggerFactory.getLogger(MySQLReportersRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.repository.ReportersRepository#getRepoters()
	 */
	@Override
	public List<Repotees> getListForEmployeesForManager(int managerId, int trainingId) {
		try {
			String sql = SqlQueryConstants.GET_REPOTEES_FOR_MANAGER;
			Object[] params = new Object[] { "Not Nominated", trainingId, managerId };
			List<Repotees> repoteeList = jdbcTemplate.query(sql, params, (rs, rows) -> {
				Repotees rep = new Repotees();
				rep.setEmpId(rs.getInt(1) + "");
				rep.setName(rs.getString(2));
				rep.setStatus(rs.getString(3));
				return rep;
			});
			return repoteeList;
		} catch (Exception e) {
			return null;
		}
	}

}
