package com.exilant.jigyasa.repository;

import java.util.List;

import com.exilant.jigyasa.vo.AttendanceResponse;
import com.exilant.jigyasa.vo.Attendees;
import com.exilant.jigyasa.vo.RequestStatus;

public interface AttendenceRepository {
	boolean markAttendence(RequestStatus markAttendence);

	/**
	 * @param trainingId
	 * @param date
	 * @return
	 */
	List<AttendanceResponse> fetchAttendence(int trainingId, String date);

	/**
	 * @param employeeId
	 * @param trainingId
	 * @return
	 */
	List<Attendees> fetchAttendeeList(int employeeId, int trainingId);
}
