/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingList.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

/**
 * @author lakshmi.bhat
 *
 */
public class TrainingList {
	private int employeeId;
	private int designation;
	private int trainingId;

	private int hasVoted;

	public TrainingList() {
	}

	
	
	public TrainingList(int employeeId, int designation) {
		super();
		this.employeeId = employeeId;
		this.designation = designation;
	}



	public TrainingList(int designation, int employeeId, int trainingId) {
		super();
		this.designation = designation;
		this.employeeId = employeeId;
		this.trainingId = trainingId;
	}

	public int getHasVoted() {
		return hasVoted;
	}

	public void setHasVoted(int hasVoted) {
		this.hasVoted = hasVoted;
	}

	public int getDesignation() {
		return designation;
	}

	public void setDesignation(int designation) {
		this.designation = designation;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	@Override
	public String toString() {
		return "TrainingList [designation=" + designation + ", employeeId=" + employeeId + ", trainingId=" + trainingId
				+ ", hasVoted=" + hasVoted + "]";
	}

}
