package com.exilant.jigyasa.vo;

public class RequestTraining {
	private String trainerName;
	private int employeeId;
	private String employeeName;
	private int managerId;
	private int trainingId;
	private String status;

	public String getStatus() {
		return status;
	}
	/**
	 * @return the trainerName
	 */
	public String getTrainerName() {
		return trainerName;
	}

	/**
	 * @param trainerName the trainerName to set
	 */
	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	public RequestTraining() {
		super();
	}

	

	public RequestTraining(String trainerName, int employeeId, String employeeName, int managerId, int trainingId,
			String status) {
		super();
		this.trainerName = trainerName;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.managerId = managerId;
		this.trainingId = trainingId;
		this.status = status;
	}
	@Override
	public String toString() {
		return "RequestTraining [employeeId=" + employeeId + ", employeeName=" + employeeName + ", managerId="
				+ managerId + ", trainingId=" + trainingId + ", status=" + status + "]";
	}

}
