/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * MySQLNominateForTrainingRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.NominateForTrainingRepository;
import com.exilant.jigyasa.vo.ScheduledTrainingNominee;
import com.exilant.jigyasa.vo.Trainer;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLNominateForTrainingRepository implements NominateForTrainingRepository {
	static final Logger logger = LoggerFactory.getLogger(MySQLNominateForTrainingRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<?> nominateEmp(ScheduledTrainingNominee nominee) {
		int nominateCount = 0;
		int requestCount = 0;
		List<Trainer> RequestedEmpList = new ArrayList<>();
		List<String> error = new ArrayList<>();
		try {
			nominee.setStatus("Nominated");
			for (Integer nomineeId : nominee.getNomineeId()) {
				String getCount = SqlQueryConstants.GET_COUNT;
				Object[] parameters = new Object[] { nominee.getTrainingId(), nomineeId.intValue() };
				nominateCount = jdbcTemplate.queryForObject(getCount, parameters, (rs, rowNum) -> rs.getInt(1));
				if (nominateCount > 0) {
					continue;
				}
				String query = "select count(*) from Scheduled_Training_Request where Scheduled_Training_Id = ? and Training_requestor_Id = ?";
				Object[] params = new Object[] { nominee.getTrainingId(), nomineeId.intValue()};
				requestCount = jdbcTemplate.queryForObject(query, params, (rs, rowNum) -> rs.getInt(1));
				if (requestCount > 0) {
					String queryToSelectEmp = "select Employee_Name from Employees where Employee_Id = ?";
					String empName = jdbcTemplate.queryForObject(queryToSelectEmp, new Object[] { nomineeId.intValue() }, (rs, rows) -> rs.getString(1));
					Trainer requestedEmp = new Trainer();
					requestedEmp.setEmployeeId(nomineeId.intValue()+"");
					requestedEmp.setEmployeeName(empName);
					RequestedEmpList.add(requestedEmp);
				}
				if(RequestedEmpList.isEmpty()) {
				String nominated = "Nominated";
				String sql = SqlQueryConstants.INSERT_SCHEDULED_TRAINING_NOMINEE;
				Object[] queryParameters = new Object[] { nominee.getTrainingId(), nomineeId.intValue(),
						nominee.getEmployeeId(), nominated };
				jdbcTemplate.update(sql, queryParameters);
				
				String queryToDecreaseSeats = SqlQueryConstants.DECREMENT_NO_OF_SEATS;
				jdbcTemplate.update(queryToDecreaseSeats, new Object[] { nominee.getTrainingId() });
				}
			}
			return RequestedEmpList;
		} catch (Exception e) {
			logger.error("There was a problem with the MySQL query: "+e);
			error.add("some error");
			return error;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.repository.NominateForTrainingRepository#
	 * selfDeclineNomination(int, int, java.lang.String)
	 */
	@Override
	public boolean selfDeclineNomination(int employeeId, int trainingId, String reasonForDecline) {
		try {
			String sql = SqlQueryConstants.UPDATE_TRAINING_NOMINEE;
			Object[] params = new Object[] { reasonForDecline, trainingId, employeeId };
			int rows = jdbcTemplate.update(sql, params);
			if (rows > 0) {
				String queryToIncrementSeats = SqlQueryConstants.INCREMENT_NO_OF_SEATS;
				jdbcTemplate.update(queryToIncrementSeats, new Object[] { trainingId });
				return true;
			}
		} catch (Exception e) {
			logger.error("Updation failed");
			return false;
		}
		return false;
	}
}
