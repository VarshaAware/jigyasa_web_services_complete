package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.DeleteSuggestedTrainingController;
import com.exilant.jigyasa.service.DeleteSuggestedTrainingService;
import com.exilant.jigyasa.vo.SuggestTraining;

@RestController
@CrossOrigin
public class DeleteSuggestedTrainingControllerImpl implements DeleteSuggestedTrainingController {
	static final Logger logger = LoggerFactory.getLogger(UpdateSuggestionTrainingStatusControllerImpl.class);
	@Autowired
	DeleteSuggestedTrainingService deleteSuggestedTrainingService;

	@Override
	@RequestMapping(value = URIConstants.DELETE_SUGGESTED_TRAINING, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> deleteSuggestionTraining(@RequestBody SuggestTraining reqObj) throws Exception {
		try {
			boolean val = deleteSuggestedTrainingService.deleteSuggestedTrainingService(reqObj);
			if (val) {
				Map<String, String> map = new HashMap<>();
				map.put("status", "success");
				return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
			}
			Map<String, String> map = new HashMap<>();
			map.put("status", "unsuccess");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Request body is not proper");
			Map<String, String> map = new HashMap<>();
			map.put("status", "Problem in fetcing request data");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
	}
}