/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 10-May-2017
  * ReportersRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository;

import java.util.List;

import com.exilant.jigyasa.vo.Repotees;

/**
 * @author lakshmi.bhat
 *
 */
public interface ReportersRepository {
	List<Repotees> getListForEmployeesForManager(int managerId, int trainingId);
}
