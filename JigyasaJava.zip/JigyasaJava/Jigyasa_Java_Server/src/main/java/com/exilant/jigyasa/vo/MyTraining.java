/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * MyTraining.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author lakshmi.bhat
 *
 */
public class MyTraining {
	private String location;
	private String endDateTime;
	private String image;
	private String trainingId;
	private String description;
	private String title;
	private String startDateTime;
	private String seats;
	@JsonProperty("trainers")
	private List<Trainer> trainer;
	private List<Nominee> nominees;
	private List<Nominee> requests;
	private String link;
	private String id;
	private String state;
	private String courseId;

	
	/**
	 * @return the courseId
	 */
	public String getCourseId() {
		return courseId;
	}

	/**
	 * @param courseId the courseId to set
	 */
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * @param link the link to set
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the trainer
	 */
	public List<Trainer> getTrainer() {
		return trainer;
	}

	/**
	 * @param trainer
	 *            the trainer to set
	 */
	public void setTrainer(List<Trainer> trainer) {
		this.trainer = trainer;
	}

	/**
	 * @return the nominees
	 */
	public List<Nominee> getNominees() {
		return nominees;
	}

	/**
	 * @param nominees
	 *            the nominees to set
	 */
	public void setNominees(List<Nominee> nominees) {
		this.nominees = nominees;
	}

	/**
	 * @return the requests
	 */
	public List<Nominee> getRequests() {
		return requests;
	}

	/**
	 * @param requests
	 *            the requests to set
	 */
	public void setRequests(List<Nominee> requests) {
		this.requests = requests;
	}


	public MyTraining() {
	}



	public MyTraining(String location, String endDateTime, String image, String trainingId, String description,
			String title, String startDateTime, String seats,  String link, String state) {
		super();
		this.location = location;
		this.endDateTime = endDateTime;
		this.image = image;
		this.trainingId = trainingId;
		this.description = description;
		this.title = title;
		this.startDateTime = startDateTime;
		this.seats = seats;
		this.link = link;
		this.state = state;
	}

	/**
	 * @return the seats
	 */
	public String getSeats() {
		return seats;
	}

	/**
	 * @param seats
	 *            the seats to set
	 */
	public void setSeats(String seats) {
		this.seats = seats;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location
	 *            the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDateTime() {
		return endDateTime;
	}

	/**
	 * @param endDate
	 *            the endDate to set
	 */
	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/**
	 * @return the trainingId
	 */
	public String getTrainingId() {
		return trainingId;
	}

	/**
	 * @param trainingId
	 *            the trainingId to set
	 */
	public void setTrainingId(String trainingId) {
		this.trainingId = trainingId;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDateTime() {
		return startDateTime;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MyTraining [location=" + location + ", endDateTime=" + endDateTime + ", image=" + image
				+ ", trainingId=" + trainingId + ", description=" + description + ", title=" + title
				+ ", startDateTime=" + startDateTime + ", seats=" + seats + ", trainer=" + trainer + ", nominees="
				+ nominees + ", requests=" + requests + ", link=" + link + ", id=" + id + ", state=" + state + "]";
	}
}
