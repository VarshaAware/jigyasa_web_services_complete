/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * GetManagerListControllerImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.GetManagerListController;
import com.exilant.jigyasa.service.GetManagerListService;
import com.exilant.jigyasa.vo.ManagerList;

/**
 * @author swathi.m
 *
 */
@Controller
public class GetManagerListControllerImpl implements GetManagerListController {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.controller.GetManagerListController#getManagerList(
	 * com.exilant.jigyasa.vo.ManagerList)
	 */

	@Autowired
	GetManagerListService managerListService;

	@Override
	@RequestMapping(value = URIConstants.GET_MANAGER_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getManagerList(@RequestBody(required = false) ManagerList managerList) throws Exception {
		// TODO Auto-generated method stub
		List<ManagerList> managersList = managerListService.getManagerList(managerList);
		if (managersList != null) {
			Map<String, List<ManagerList>> map = new HashMap<String, List<ManagerList>>();
			map.put("managerList", managersList);
			return new ResponseEntity<Map<String, List<ManagerList>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("errorMessage", "someError");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);

	}
}
