/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 27-Apr-2017
  * MySQLLoginRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.ColumnNameConstants;
import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.LoginRepository;
import com.exilant.jigyasa.vo.Employee;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLLoginRepository implements LoginRepository {

	static final Logger logger = LoggerFactory.getLogger(MySQLLoginRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public Employee getEmployeeDetails(String userName) {

		String sql = SqlQueryConstants.GET_EMPLOYEE_DETAILS;
		String mailId = userName;
		Employee employee = null;
		if (!mailId.contains("@exilant.com")) {
			mailId = mailId + "@exilant.com";
		}
		try {
			employee = jdbcTemplate.queryForObject(sql, new Object[] { mailId },
					(rs, rowNum) -> new Employee(rs.getInt(ColumnNameConstants.EMPLOYEE_ID),
							rs.getString(ColumnNameConstants.EMPLOYEE_NAME), rs.getString(ColumnNameConstants.EMAIL_ID),
							rs.getString(ColumnNameConstants.ACTIVE).charAt(0), rs.getInt(ColumnNameConstants.ROLE_ID),
							rs.getString(ColumnNameConstants.CONTACT_NO), rs.getInt(ColumnNameConstants.MANAGER_ID),
							rs.getString(ColumnNameConstants.DESIGNATION)));
		} catch (EmptyResultDataAccessException e) {
			logger.error("Invalid User Name " + e.getMessage());
		}
		return employee;
	}

}
