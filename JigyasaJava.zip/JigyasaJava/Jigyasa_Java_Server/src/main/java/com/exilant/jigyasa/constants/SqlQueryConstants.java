/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 27-Apr-2017
  * SqlQueryConstants.java
  *
  *******************************************************/

package com.exilant.jigyasa.constants;

/**
 * @author lakshmi.bhat
 *
 */
public class SqlQueryConstants {
	public static final String GET_EMPLOYEE_DETAILS = "SELECT * FROM Employees WHERE Email_Id = ?";
	public static final String GET_SCHEDULED_TRAINING = "SELECT * FROM Scheduled_Training where Scheduled_Training_Id = ?";
	public static final String INSERT_REQUEST_TRAINING = " INSERT INTO Scheduled_Training_Request (Scheduled_Training_Id, Training_requestor_Id, Training_requestor_Name, Training_requestor_ManagerId) VALUES (?,?,?,?)";
	public static final String INSERT_SUGGEST_TRAINING = "INSERT INTO Courses (Course_Name, Course_Description, Course_Suggested_By) VALUES (?,?,?)";
	public static final String INSERT_SCHEDULED_TRAINING_NOMINEE = "Insert into Scheduled_Training_Nominee (Scheduled_Training_Id, Training_nominee_Id, Training_nominee_ManagerId, Status) values (?,?,?,?)";
	public static final String UPDATE_SCHEDULED_TRAINING_STATUS = "Update Courses set Course_Status = ? WHERE Course_Name = ? AND Course_Suggested_By = ?";
	public static final String UPDATE_TRAINING_REQUEST = "Update Scheduled_Training_Request set Status = ? WHERE Scheduled_Training_Id = ? AND Training_requestor_Id = ?";
	public static final String INSERT_COURSES = "INSERT INTO Courses(Course_Name, Course_Image, Course_Description, Course_Links, State)  VALUES (?, ?, ?, ?, ?)";
	public static final String GET_COURSE_ID = "SELECT Course_Id from Courses ORDER BY Course_Id DESC LIMIT 1";
	public static final String GET_TRAINING_LOCATION_ID = "SELECT Training_Location_Id FROM Training_Location where Training_Room = ?";
	public static final String INSERT_SCHEDULED_TRAINING = "INSERT INTO Scheduled_Training(Course_Id,Training_Location_Id,Seats) VALUES(?,?,?)";
	public static final String INSERT_SCHEDULED_TRAINING_TIME = "INSERT INTO Scheduled_Training_Time(Scheduled_Training_Id,Training_Start_Time , Training_End_Time) VALUES (?,?,?)";
	public static final String INSERT_TRAINERS = "INSERT INTO Trainers(Trainer_Id) VALUES (?)";
	public static final String INSERT_TRAINING_NOTIFICATIONS = "INSERT INTO Training_Notifications(Scheduled_Training_Id, Mail_Notification_Type, Mail_Notification_Subject, Mail_Notification_Content, Mail_notification_Rcp_Type ) VALUES (?, ?, ?, ?, ?)";
	public static final String GET_VOTE_COUNT = "SELECT COUNT(*) FROM Vote WHERE CourseId = ? AND EmployeeId = ?";
	public static final String INSERT_NEW_VOTE = "INSERT INTO Vote(CourseId,EmployeeId,HasVoted) VALUES (?,?,?)";
	public static final String UPDATE_VOTE = "UPDATE Courses SET Votes = Votes + 1 WHERE Course_Id = ?";
	public static final String GET_LOCATION_LIST = "SELECT Training_Location_Id, Training_Room FROM Training_Location";
	public static final String NO_OF_TRAINERS = "SELECT count(*) from Trainers where Trainer_id = ?";
	public static final String GET_EMPLOYEE_NAME = "SELECT Employee_Id , Employee_Name from Employees where Employee_Id = ?";
	public static final String INSERT_TRAINERS_ID_NAME = "INSERT INTO Trainers (Trainer_Id, Trainer_Name) VALUES (?, ? )";
	public static final String GET_SCHEDULED_TRAINING_ID = "SELECT Scheduled_Training_Id FROM Scheduled_Training  ORDER BY Scheduled_Training_Id DESC LIMIT 1";
	public static final String INSERT_TRAINERS_NOMINATED_FOR_TRAINING = "INSERT INTO Trainers_Nominated_For_Training (Scheduled_Training_Id,Trainer_Id) VALUES (?,?)";
	public static final String INSERT_MANAGERS_NOMINATED_FOR_TRAINING = "INSERT into Managers_Nominated_For_Training (Scheduled_Training_Id,Manager_Id) VALUES (?,?)";
	public static final String GET_COURSEID = "SELECT Course_Id FROM Scheduled_Training WHERE Scheduled_Training_Id = ?";
	public static final String UPDATE_COURSES = "UPDATE trainingappdb.Courses Set Course_Name = ?, Course_Description = ?, Course_Links = ?, Course_Image = ?, State = ? where Course_Id = ?";
	public static final String UPDATE_SCHEDULED_TRAINING = "UPDATE Scheduled_Training Set Training_Location_Id = ?, Seats = ? WHERE Scheduled_Training_Id = ?";
	public static final String UPDATE_SCHEDULED_TRAINING_TIME = "UPDATE Scheduled_Training_Time Set Training_Start_Time = ?, Training_End_Time = ? WHERE Scheduled_Training_Id = ?";
	public static final String UPDATE_TRAINING_NOTIFICATIONS = "UPDATE Training_Notifications Set Mail_Notification_Type = ?, Mail_Notification_Subject = ?, Mail_Notification_Content = ? WHERE Scheduled_Training_Id = ?";
	public static final String DELETE_TRAINERS_NOMINATED_FOR_TRAINING = "DELETE FROM Trainers_Nominated_For_Training WHERE scheduled_Training_Id = ?";
	public static final String GET_TRAINERS_NOMINATED_FOR_TRAINING = "SELECT * FROM trainingappdb.Trainers_Nominated_For_Training WHERE Scheduled_Training_Id = ? && Trainer_Id IN (?) ";
	public static final String DELETE_MANAGERS_NOMINATED_FOR_TRAINING = "DELETE FROM Managers_Nominated_For_Training WHERE scheduled_Training_Id = ?";
	public static final String GET_MANAGERS_NOMINATED_FOR_TRAINING = "SELECT * FROM Managers_Nominated_For_Training WHERE Scheduled_Training_Id = ? && Manager_Id IN (?) ";
	public static final String GET_SCHEDULED_TRAINING_REQUEST_DETAILS="SELECT * FROM Scheduled_Training_Request where Training_requestor_ManagerId = ? AND Scheduled_Training_Id = ?";
	public static final String GET_SCHEDULED_TRAINING_LIST="SELECT c.Course_Name, c.Course_Id, c.Course_Suggested_By, c.Course_Description, e.Employee_Name, c.Votes ,COALESCE(v.HasVoted, 0) AS `HasVoted` FROM (Courses as c left join Employees as e on e.Employee_Id = c.Course_Suggested_By) left join Vote as v on c.Course_Id = v.CourseId AND v.EmployeeId = ? WHERE c.Course_Status != ? OR c.state = ?";
	public static final String INSERT_MARK_ATTENDENCE="INSERT INTO Attendance(Training_Id,Attendee_Id,Training_Date) VALUES(?,?,?)";
	public static final String DELETE_SUGGESTED_TRAINING="Delete Courses, Vote from Courses,Vote where Courses.Course_Id = ? and Vote.CourseId = ?";
	public static final String GET_COUNT = "SELECT count(*) FROM Scheduled_Training_Nominee where Scheduled_Training_Id = ? and Training_nominee_Id = ?";
	public static final String UPDATE_TRAINING_NOMINEE = "Update Scheduled_Training_Nominee set Decline_Reason = ?, Status =  'Declined' where Scheduled_Training_Id = ? and Training_nominee_Id = ?";
	public static final String GET_COURSE_LOCATION_ID = "SELECT Course_Id, Training_Location_Id, Seats FROM Scheduled_Training WHERE Scheduled_Training_Id = ?";
	public static final String GET_NOMINEE_ID = "SELECT Training_nominee_Id, Status FROM Scheduled_Training_Nominee WHERE Scheduled_Training_Id = ?";
	public static final String GET_REQUESTOR_ID = "SELECT Training_requestor_Id, Status FROM Scheduled_Training_Request WHERE Scheduled_Training_Id = ? AND Training_requestor_ManagerId = ?";
	public static final String GET_ID_FROM_NOMINEE_ID = "SELECT s.Scheduled_Training_Id,s.Course_Id, s.Training_Location_Id FROM Scheduled_Training as s inner join Scheduled_Training_Nominee as e on  s.Scheduled_Training_Id = e.Scheduled_Training_Id where  e.Training_nominee_Id = ?   union SELECT s.Scheduled_Training_Id,s.Course_Id, s.Training_Location_Id FROM Scheduled_Training as s inner join Trainers_Nominated_For_Training as e on s.Scheduled_Training_Id = e.Scheduled_Training_Id where e.Trainer_Id = ?";
	public static final String GET_ALL_COURSE_LOCATION_ID = "SELECT Scheduled_Training_Id, Course_Id, Training_Location_Id FROM Scheduled_Training";
	public static final String GET_TRAINING_ID_FOR_MY_TRAINING = "SELECT stn.Scheduled_Training_Id FROM Scheduled_Training_Nominee as stn inner join Scheduled_Training_Time as stt on stn.Scheduled_Training_Id = stt.Scheduled_Training_Id WHERE stn.Training_nominee_Id = ? and stn.Status != ? and stt.Training_End_Time >= ? ";
	public static final String GET_TRAINING_ID_FOR_STATUS_APPROVED = "SELECT str.Scheduled_Training_Id FROM trainingappdb.Scheduled_Training_Request as str inner join Scheduled_Training_Time as stt on str.Scheduled_Training_Id = stt.Scheduled_Training_Id where str.Training_requestor_Id = ? and str.Status = ? and stt.Training_End_Time >= ?;";
	public static final String GET_IDS = "SELECT Course_Id, Training_Location_Id, Seats FROM Scheduled_Training where Scheduled_Training_Id = ?";
	public static final String GET_IDS_FOR_ALL_TRAINING = "SELECT st.Scheduled_Training_Id,st.Course_Id, st.Training_Location_Id,st.Seats FROM Scheduled_Training as st inner join trainingappdb.Scheduled_Training_Time as stt on st.Scheduled_Training_Id = stt.Scheduled_Training_Id  where stt.Training_Start_Time > ? ";
	public static final String GET_COURSEDETAIL_ON_STATE = "SELECT Course_Name,State,Course_Image FROM Courses WHERE Course_Id = ?  AND State != ? AND State != ?";
	public static final String GET_IDS_FOR_TODAY_TRAINING = "SELECT st.Scheduled_Training_Id,st.Course_Id, st.Training_Location_Id, st.Seats FROM Scheduled_Training as st inner join trainingappdb.Scheduled_Training_Time as stt on st.Scheduled_Training_Id = stt.Scheduled_Training_Id  WHERE ? BETWEEN DATE(Training_Start_Time) AND DATE(Training_End_Time) ";
	public static final String GET_COURSE_OBJECT = "SELECT Course_Name, Course_Image, Course_Description, Course_Links, State FROM Courses WHERE Course_Id = ?";
	public static final String GET_TRAINER_LIST = "select e.Employee_Id, e.Employee_Name, e.Contact_No from Employees as e left join Trainers_Nominated_For_Training as tnft on e.Employee_Id = tnft.Trainer_Id where tnft.Scheduled_Training_Id = ?";
	public static final String GET_COURSE_DETAIL_FOR_SUGGESTED_TRAINING = "SELECT c.Course_Name, c.Course_Id, c.Course_Suggested_By, c.Course_Description, e.Employee_Name, c.Votes ,COALESCE(v.HasVoted, 0) AS `HasVoted` FROM (Courses as c left join Employees as e on e.Employee_Id = c.Course_Suggested_By) left join Vote as v on c.Course_Id = v.CourseId AND v.EmployeeId = ? WHERE c.Course_Status != ? OR c.state = ?";
	public static final String GET_LOCATION = "SELECT Training_Room FROM Training_Location WHERE Training_Location_Id = ?";
	public static final String GET_TIME = "SELECT Training_Start_Time, Training_End_Time FROM Scheduled_Training_Time WHERE Scheduled_Training_Id = ?";
	public static final String GET_REQUESTS = "SELECT str2.Scheduled_Training_Id, str2.Training_requestor_Id, str2.Training_requestor_Name, str2.Status FROM Scheduled_Training_Request as str1 inner join Scheduled_Training_Request as str2 on str1.Scheduled_Training_Id = str2.Scheduled_Training_Id  where str1.Training_requestor_ManagerId = ? ";
	public static final String GET_TRAINERS = "SELECT Trainer_Id, Trainer_Name FROM Trainers";
	public static final String GET_EMPLOYEE = "SELECT Employee_Id, Employee_Name FROM Employees WHERE Employee_Name = ?";
	public static final String GET_REPOTEES_FOR_MANAGER = "SELECT emp.Employee_Id, emp.Employee_Name,  COALESCE(stn.Status, ?) AS `Status` FROM (Employees as emp left join Scheduled_Training_Nominee as stn on emp.Employee_Id = stn.Training_nominee_Id And stn.Scheduled_Training_Id = ? ) WHERE emp.Manager_Id = ?;";
	public static final String GET_ATTENDANCE = "select  finalAttendance.AttendeesID, emp.Employee_Name, finalAttendance.Has_Attended  from Employees as emp,( select ateendees.* from (select COALESCE(Training_nominee_Id) AS `AttendeesID`, Scheduled_Training_Id, 0 as `Has_Attended` from Scheduled_Training_Nominee as stn where Scheduled_Training_Id = ? and Status = ? union select Training_requestor_Id , Scheduled_Training_Id , 0 as `Has_Attended`from Scheduled_Training_Request as str where Scheduled_Training_Id = ? and Status = ? )as ateendees where not exists (select 1 from Attendance as aa where ateendees.AttendeesID = aa.Attendee_Id and aa.Training_Id = ateendees.Scheduled_Training_Id and Training_Date = ? and aa.Has_Attended = 1) union  select Attendee_Id, Training_Id , Has_Attended from Attendance where Training_Date is Null or Training_Date = ? ) as finalAttendance where emp.Employee_Id = finalAttendance.AttendeesID order by emp.Employee_Name;";
	public static final String GET_FETCH_DETAILS_COURSE_ID = "SELECT Course_Id FROM Scheduled_Training WHERE Scheduled_Training_Id = ?";
    public static final String GET_TRAINER_ID = "SELECT Trainer_Id FROM Trainers_Nominated_For_Training WHERE Scheduled_Training_Id = ?";
    public static final String GET_MANAGER_ID = "SELECT Manager_Id FROM Managers_Nominated_For_Training WHERE Scheduled_Training_Id = ?";
    public static final String GET_NOTIFICATION = "SELECT Mail_Notification_type,Mail_Notification_Content,Mail_Notification_Rcp_Type FROM Training_Notifications WHERE Scheduled_Training_Id = ?";
    public static final String GET_COURSE_DETAILS = "SELECT Course_Description,Course_Links FROM Courses WHERE Course_Id = ?";
    public static final String GET_SCHEDULED_TRAININGS =  "SELECT st.Scheduled_Training_Id,st.Course_Id, st.Training_Location_Id,st.Seats FROM Scheduled_Training as st inner join trainingappdb.Scheduled_Training_Time as stt on st.Scheduled_Training_Id = stt.Scheduled_Training_Id  where stt.Training_Start_Time > ? ";
    public static final String DECREMENT_NO_OF_SEATS = "update Scheduled_Training set Seats = Seats - 1 where Scheduled_Training_Id = ? and Seats > 0";
    public static final String INCREMENT_NO_OF_SEATS = "update Scheduled_Training set Seats = Seats + 1 where Scheduled_Training_Id = ?";
    public static final String OTHER_EMPLOYEE_LIST = "SELECT Employee_Id,Employee_Name FROM Employees where Employee_Id not in( select Trainer_Id from Trainers)";
    public static final String UPDATE_COURSES_FOR_DELETE_TRAINING = "UPDATE Courses SET state = 'Deleted' WHERE Course_Id = ?";
    public static final String GET_EMPLOYEES = "SELECT * FROM Employees WHERE Role_Id = 2;";
    public static final String GET_ATTENDEES = "select attendees.*, emp.Employee_Name from (select COALESCE(Training_nominee_Id) AS `EmployeeID` from Scheduled_Training_Nominee where Scheduled_Training_Id = ? and Status = ? and Training_nominee_ManagerId = ? union select Training_requestor_Id from Scheduled_Training_Request where Scheduled_Training_Id = ? and Status = ? and Training_requestor_ManagerId = ?) as attendees left join Employees as emp on attendees.EmployeeID = emp.Employee_Id;";
}

