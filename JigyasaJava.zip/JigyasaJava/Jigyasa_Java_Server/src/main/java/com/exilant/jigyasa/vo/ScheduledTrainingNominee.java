/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * ScheduledTrainingNominee.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import java.util.List;

/**
 * @author lakshmi.bhat
 *
 */
public class ScheduledTrainingNominee {
	private int trainingId;
	private int employeeId;
	private List<Integer> nomineeId;
	private String status;

	public ScheduledTrainingNominee() {
	}

	public ScheduledTrainingNominee(int trainingId, int employeeId, List<Integer> nomineeId, String status) {
		super();
		this.trainingId = trainingId;
		this.employeeId = employeeId;
		this.nomineeId = nomineeId;
		this.status = status;
	}

	/**
	 * @return the trainingId
	 */
	public int getTrainingId() {
		return trainingId;
	}

	/**
	 * @param trainingId
	 *            the trainingId to set
	 */
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}

	/**
	 * @return the employeeId
	 */
	public int getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId
	 *            the employeeId to set
	 */
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the nomineeId
	 */
	public List<Integer> getNomineeId() {
		return nomineeId;
	}

	/**
	 * @param nomineeId
	 *            the nomineeId to set
	 */
	public void setNomineeId(List<Integer> nomineeId) {
		this.nomineeId = nomineeId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ScheduledTrainingNominee [trainingId=" + trainingId + ", employeeId=" + employeeId + ", nomineeId="
				+ nomineeId + ", status=" + status + "]";
	}

}
