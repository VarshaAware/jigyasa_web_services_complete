/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 17-May-2017
>  * FetchDetailsForEditService.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.FetchDetailForEdit;
import com.exilant.jigyasa.vo.Training;

/**
 * @author swathi.m
 *
 */
public interface FetchDetailsForEditService {
	FetchDetailForEdit fetchDetailsForEditService(Training training);
}
