/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 08-May-2017
  * LoginVo.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author lakshmi.bhat
 *
 */
public class LoginVo {
	@JsonProperty("status")
	private Status status;
	
	@JsonProperty("userInfo")
	private Employee employee;
	
	public LoginVo() {}
	
	public LoginVo(Status status, Employee employee) {
		super();
		this.status = status;
		this.employee = employee;
	}
	
	/**
	 * @return the status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * @return the employee
	 */
	public Employee getEmployee() {
		return employee;
	}

	/**
	 * @param employee the employee to set
	 */
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "LoginVo [status=" + status + ", employee=" + employee + "]";
	}
	
}
