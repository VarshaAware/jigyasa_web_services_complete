/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 17-May-2017
>  * FetchDetailsForEditControllerImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.FetchDetailsForEditController;
import com.exilant.jigyasa.service.FetchDetailsForEditService;
import com.exilant.jigyasa.vo.FetchDetailForEdit;
import com.exilant.jigyasa.vo.Training;

/**
 * @author swathi.m
 *
 */

@RestController
public class FetchDetailsForEditControllerImpl implements FetchDetailsForEditController {

	@Autowired
	FetchDetailsForEditService fetchDetailsForEdit;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.controller.FetchDetailsForEditController#
	 * fetchDetailsForEdit(com.exilant.jigyasa.vo.Training)
	 */
	@Override
	@RequestMapping(value = URIConstants.FETCH_DETAILS_FOR_EDIT, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> fetchDetailsForEdit(@RequestBody Training training) throws Exception {
		// TODO Auto-generated method stub
		FetchDetailForEdit fetchDetailForEdit = fetchDetailsForEdit.fetchDetailsForEditService(training);
		if (fetchDetailForEdit != null) {
			return new ResponseEntity<FetchDetailForEdit>(fetchDetailForEdit, HttpStatus.OK);
		}
		return null;
	}

}
