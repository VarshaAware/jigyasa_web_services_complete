package com.exilant.jigyasa.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.exilant.jigyasa.repository.LocationListRepository;
import com.exilant.jigyasa.service.LocationListService;
import com.exilant.jigyasa.vo.TrainingLocation;

@Service
public class LocationListServiceImpl implements LocationListService {

	@Autowired
	LocationListRepository locationListRepository;

	@Override
	public List<TrainingLocation> getlocationList(TrainingLocation location) {
		List<TrainingLocation> locationList = new ArrayList<TrainingLocation>();
		locationList = locationListRepository.getLocationList();
		return locationList;
	}

}
