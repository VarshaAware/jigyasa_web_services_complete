/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * MySQLTrainingListRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.TrainingListRepository;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.Nominee;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.Schedule;
import com.exilant.jigyasa.vo.Scheduled_Training;
import com.exilant.jigyasa.vo.SuggestedTraining;
import com.exilant.jigyasa.vo.Trainer;
import com.exilant.jigyasa.vo.Training;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLTrainingListRepository implements TrainingListRepository {
	static final Logger logger = LoggerFactory.getLogger(MySQLTrainingListRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	TrainingListResponse trainingList = null;
	MyTraining trainingDetail = null;

	@Override
	public TrainingListResponse getTrainingList(int employeeId, int roleId) {
		trainingList = new TrainingListResponse();

		try {
			List<MyTraining> myTrainingList = getMyTrainings(employeeId);
			List<MyTraining> allTrainingList = getAllTrainings(roleId);
			List<MyTraining> todayTrainingList = getTodayTrainingList();
			List<SuggestedTraining> suggestedTainingList = getSuggestedTainings(employeeId);

			trainingList.setUpComingTrainings(allTrainingList);
			trainingList.setMyTrainings(myTrainingList);
			trainingList.setTodayTrainings(todayTrainingList);
			trainingList.setTrainingSuggestions(suggestedTainingList);

			return trainingList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public TrainingListResponse getTrainingListForManager(int employeeId, int roleId) {
		trainingList = new TrainingListResponse();
		try {
			List<MyTraining> myTrainingList = getMyTrainings(employeeId);
			List<MyTraining> allTrainingList = getAllTrainings(roleId);
			List<MyTraining> todayTrainingList = getTodayTrainingList();
			List<SuggestedTraining> suggestedTainingList = getSuggestedTainings(employeeId);
			List<RequestTraining> requests = getRequests(employeeId);

			trainingList.setUpComingTrainings(allTrainingList);
			trainingList.setMyTrainings(myTrainingList);
			trainingList.setTodayTrainings(todayTrainingList);
			trainingList.setTrainingSuggestions(suggestedTainingList);
			trainingList.setRequest(requests);
			return trainingList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public MyTraining getTrainingDetails(int trainingId, int employeeId) {
		trainingDetail = new MyTraining();
		String sql = SqlQueryConstants.GET_COURSE_LOCATION_ID;
		Object[] queryParameters = new Object[] { trainingId };
		Scheduled_Training schecduledTraining = null;
		try {
			schecduledTraining = jdbcTemplate.queryForObject(sql, queryParameters, (rs, rowNum) -> {
				Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
				schecduledTrainingObj.setCourseId(rs.getInt(1) + "");
				schecduledTrainingObj.setTrainingLocationId(rs.getInt(2) + "");
				schecduledTrainingObj.setSeats(rs.getInt(3) + "");
				return schecduledTrainingObj;
			});
		} catch (Exception e) {
			return null;
		}
		if (schecduledTraining != null) {
			Training course = getCourseObject(schecduledTraining.getCourseId());

			String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

			Schedule time = getTrainingTime(trainingId + "");

			String querToGetNominees = SqlQueryConstants.GET_NOMINEE_ID;
			List<Nominee> nominees = jdbcTemplate.query(querToGetNominees, new Object[] { trainingId },
					(rs, rowNum) -> {
						Nominee nominee = new Nominee();
						nominee.setId(rs.getInt(1) + "");
						nominee.setStatus(rs.getString(2));
						return nominee;
					});

			String queryToGetRequests = SqlQueryConstants.GET_REQUESTOR_ID;
			List<Nominee> requestors = jdbcTemplate.query(queryToGetRequests, new Object[] { trainingId, employeeId },
					(rs, rowNum) -> {
						Nominee nominee = new Nominee();
						nominee.setId(rs.getInt(1) + "");
						nominee.setStatus(rs.getString(2));
						return nominee;
					});

			List<Trainer> trainers = getTrainerList(trainingId + "");

			String courseName = getImageStringFromTrainingName(course.getTitle());
			course.setImage(courseName);
			trainingDetail = new MyTraining(trainingRoom, time.getEndDate(), course.getImage(), "" + trainingId,
					course.getDescription(), course.getTitle(), time.getStartDate(), schecduledTraining.getSeats(),
					course.getLink(), course.getState());
			trainingDetail.setRequests(requestors);
			trainingDetail.setNominees(nominees);
			trainingDetail.setTrainer(trainers);
			trainingDetail.setSeats(schecduledTraining.getSeats());
			return trainingDetail;
		}
		return null;
	}

	@Override
	public List<MyTraining> getTrainingHistory(int employeeId) {
		List<MyTraining> trainingHistory = new ArrayList<MyTraining>();

		List<Scheduled_Training> trainings = null;
		if (employeeId != 0) {
			String sql = SqlQueryConstants.GET_ID_FROM_NOMINEE_ID;
			Object[] params = new Object[] { employeeId, employeeId };
			trainings = jdbcTemplate.query(sql, params, (rs, rows) -> {
				Scheduled_Training trainingObj = new Scheduled_Training();
				trainingObj.setScheduled_Training_Id(rs.getInt(1) + "");
				trainingObj.setCourseId(rs.getInt(2) + "");
				trainingObj.setTrainingLocationId(rs.getInt(3) + "");
				return trainingObj;
			});
		} else {
			String sql = SqlQueryConstants.GET_ALL_COURSE_LOCATION_ID;
			trainings = jdbcTemplate.query(sql, (rs, rows) -> {
				Scheduled_Training trainingObj = new Scheduled_Training();
				trainingObj.setScheduled_Training_Id(rs.getInt(1) + "");
				trainingObj.setCourseId(rs.getInt(2) + "");
				trainingObj.setTrainingLocationId(rs.getInt(3) + "");
				return trainingObj;
			});
		}
		if (trainings.size() >= 1) {
			for (Scheduled_Training training : trainings) {
				Schedule time = getTrainingTime(training.getScheduled_Training_Id());
				if (time != null) {
					String endDateString = time.getEndDate();
					DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date endDate = null;
					try {
						endDate = dateFormat.parse(endDateString);
					} catch (ParseException e) {
						logger.error("Error while parsing string to Date object");
					}
					if (endDate.before(new Date())) {
						Training course = getCourseObject(training.getCourseId());

						String trainingRoom = getTrainingLocation(training.getTrainingLocationId());

						List<Trainer> trainers = getTrainerList(training.getScheduled_Training_Id());

						MyTraining history = new MyTraining();
						history.setLocation(trainingRoom);
						history.setEndDateTime(time.getEndDate());
						String courseName = getImageStringFromTrainingName(course.getTitle());
						history.setImage(courseName);
						history.setId(training.getScheduled_Training_Id());
						history.setDescription(course.getDescription());
						history.setTitle(course.getTitle());
						history.setStartDateTime(time.getStartDate());
						history.setTrainer(trainers);
						history.setLink(course.getLink());
						history.setSeats("");
						trainingHistory.add(history);
					}
				}
			}
		}
		return trainingHistory;
	}

	private List<MyTraining> getMyTrainings(int employeeId) {
		List<MyTraining> myTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dateFormat.format(new Date());
		String declined = "Declined";

		String sqlToGetMyTrainingId = SqlQueryConstants.GET_TRAINING_ID_FOR_MY_TRAINING;
		Object[] queryParameters = new Object[] { employeeId, declined, date };
		List<String> myTrainingId = jdbcTemplate.query(sqlToGetMyTrainingId, queryParameters,
				(rs, rowNum) -> rs.getInt(1) + "");

		String approved = "Approved";
		String sqlToGetMyTrainingId1 = SqlQueryConstants.GET_TRAINING_ID_FOR_STATUS_APPROVED;
		Object[] queryParameters1 = new Object[] { employeeId, approved, date };
		List<String> myTrainingId1 = jdbcTemplate.query(sqlToGetMyTrainingId1, queryParameters1,
				(rs, rowNum) -> rs.getInt(1) + "");
		for (String val : myTrainingId1) {
			myTrainingId.add(val);
		}
		if (myTrainingId.size() > 0) {
			for (String i : myTrainingId) {
				String sql = SqlQueryConstants.GET_IDS;
				Scheduled_Training schecduledTraining = jdbcTemplate.queryForObject(sql, new Object[] { i },
						(rs, rowNum) -> {
							Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
							schecduledTrainingObj.setCourseId(rs.getInt(1) + "");
							schecduledTrainingObj.setTrainingLocationId(rs.getInt(2) + "");
							schecduledTrainingObj.setSeats(rs.getInt(3) + "");
							return schecduledTrainingObj;
						});

				Training course = null;
				if (!schecduledTraining.getCourseId().isEmpty()) {
					course = getCourseObject(schecduledTraining.getCourseId());
				}

				String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

				Schedule time = getTrainingTime(i);

				MyTraining myTraining = new MyTraining();
				myTraining.setLocation(trainingRoom);
				myTraining.setEndDateTime(time.getEndDate());
				String courseName = getImageStringFromTrainingName(course.getTitle());
				myTraining.setImage(courseName);
				myTraining.setTrainingId(i);
				myTraining.setDescription(course.getDescription());
				myTraining.setTitle(course.getTitle());
				myTraining.setStartDateTime(time.getStartDate());
				myTraining.setSeats(schecduledTraining.getSeats());
				myTraining.setLink(course.getLink());
				myTraining.setState(course.getState());
				myTrainings.add(myTraining);
			}
		}
		return myTrainings;
	}

	private List<MyTraining> getAllTrainings(int roleId) {
		List<MyTraining> allTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dateFormat.format(new Date());

		String sql = SqlQueryConstants.GET_IDS_FOR_ALL_TRAINING;
		List<Scheduled_Training> schecduledTrainings = jdbcTemplate.query(sql, new Object[] { date }, (rs, rowNum) -> {
			Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
			schecduledTrainingObj.setScheduled_Training_Id(rs.getInt(1) + "");
			schecduledTrainingObj.setCourseId(rs.getInt(2) + "");
			schecduledTrainingObj.setTrainingLocationId(rs.getInt(3) + "");
			schecduledTrainingObj.setSeats("" + rs.getInt(4));
			return schecduledTrainingObj;
		});
		if (schecduledTrainings.size() > 0) {
			for (Scheduled_Training schecduledTraining : schecduledTrainings) {
				String drafted = "Drafted";
				String deleted = "Deleted";
				Training course = null;
				try {
					if (roleId == 1) {
						course = getCourseObject(schecduledTraining.getCourseId());

					} else {
						String queryToGetCourse = SqlQueryConstants.GET_COURSEDETAIL_ON_STATE;
						Object[] queryParameters = new Object[] { schecduledTraining.getCourseId(), drafted, deleted };
						course = jdbcTemplate.queryForObject(queryToGetCourse, queryParameters, (rs, rowNum) -> {
							Training courseObj = new Training();
							courseObj.setTitle(rs.getString(1));
							courseObj.setState(rs.getString(2));
							courseObj.setImage(rs.getString(3));
							return courseObj;
						});
					}
				} catch (EmptyResultDataAccessException e) {
					continue;
				}
				String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

				Schedule time = getTrainingTime(schecduledTraining.getScheduled_Training_Id());

				MyTraining allTraining = new MyTraining();
				allTraining.setLocation(trainingRoom);
				allTraining.setEndDateTime(time.getEndDate());
				String courseName = getImageStringFromTrainingName(course.getTitle());
				allTraining.setImage(courseName);
				allTraining.setTrainingId("" + schecduledTraining.getScheduled_Training_Id());
				allTraining.setTitle(course.getTitle());
				allTraining.setStartDateTime(time.getStartDate());
				if (schecduledTraining.getSeats().isEmpty()) {
					allTraining.setSeats("");
				} else {
					allTraining.setSeats(schecduledTraining.getSeats());
				}
				allTraining.setLink(course.getLink());
				allTraining.setState(course.getState());
				allTraining.setCourseId(schecduledTraining.getCourseId());
				allTrainings.add(allTraining);
			}
		}
		return allTrainings;
	}

	private List<MyTraining> getTodayTrainingList() {
		List<MyTraining> todayTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dateFormat.format(new Date());

		String sql = SqlQueryConstants.GET_IDS_FOR_TODAY_TRAINING;
		List<Scheduled_Training> schecduledTrainings = jdbcTemplate.query(sql, new Object[] { date }, (rs, rowNum) -> {
			Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
			schecduledTrainingObj.setScheduled_Training_Id(rs.getInt(1) + "");
			schecduledTrainingObj.setCourseId(rs.getInt(2) + "");
			schecduledTrainingObj.setTrainingLocationId(rs.getInt(3) + "");
			schecduledTrainingObj.setSeats(rs.getInt(4) + "");
			return schecduledTrainingObj;
		});
		if (schecduledTrainings.size() > 0) {
			for (Scheduled_Training schecduledTraining : schecduledTrainings) {

				Training course = getCourseObject(schecduledTraining.getCourseId());
				String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

				Schedule time = getTrainingTime(schecduledTraining.getScheduled_Training_Id());

				MyTraining todayTraining = new MyTraining();
				todayTraining.setLocation(trainingRoom);
				todayTraining.setEndDateTime(time.getEndDate());
				String courseName = getImageStringFromTrainingName(course.getTitle());
				todayTraining.setImage(courseName);
				todayTraining.setTrainingId("" + schecduledTraining.getScheduled_Training_Id());
				todayTraining.setDescription(course.getDescription());
				todayTraining.setTitle(course.getTitle());
				todayTraining.setStartDateTime(time.getStartDate());
				todayTraining.setSeats(schecduledTraining.getSeats());
				todayTraining.setLink(course.getLink());
				todayTraining.setState(course.getState());
				todayTrainings.add(todayTraining);
			}
		}
		return todayTrainings;
	}

	private Training getCourseObject(String courseId) {
		try {
			String queryToGetCourse = SqlQueryConstants.GET_COURSE_OBJECT;
			Object[] queryParameters = new Object[] { courseId };
			Training course = jdbcTemplate.queryForObject(queryToGetCourse, queryParameters, (rs, rowNum) -> {
				Training courseObj = new Training();
				courseObj.setTitle(rs.getString(1));
				courseObj.setImage(rs.getString(2));
				courseObj.setDescription(rs.getString(3));
				courseObj.setLink(rs.getString(4));
				courseObj.setState(rs.getString(5));
				return courseObj;
			});
			return course;
		} catch (Exception e) {
			return null;
		}
	}

	private List<Trainer> getTrainerList(String trainingId) {
		String queryToGetTrainers = SqlQueryConstants.GET_TRAINER_LIST;
		List<Trainer> trainers = jdbcTemplate.query(queryToGetTrainers, new Object[] { trainingId }, (rs, rows) -> {
			Trainer trainer = new Trainer();
			trainer.setEmployeeId("" + rs.getInt(1));
			trainer.setEmployeeName(rs.getString(2));
			trainer.setContactNo(rs.getString(3));
			return trainer;
		});
		return trainers;
	}

	private List<SuggestedTraining> getSuggestedTainings(int employeeId) {
		String deleted = "Deleted";
		String suggested = "Suggested";
		String sql = SqlQueryConstants.GET_COURSE_DETAIL_FOR_SUGGESTED_TRAINING;
		Object[] queryParameters = new Object[] { employeeId, deleted, suggested };
		List<SuggestedTraining> schecduledTrainings = jdbcTemplate.query(sql, queryParameters, (rs, rowNum) -> {
			SuggestedTraining suggestedTraining = new SuggestedTraining();
			suggestedTraining.setCourseName(rs.getString(1));
			suggestedTraining.setCourseId("" + rs.getInt(2));
			suggestedTraining.setSuggestedBy(rs.getString(3));
			suggestedTraining.setDescription(rs.getString(4));
			suggestedTraining.setEmployeeName(rs.getString(5));
			suggestedTraining.setVotes("" + rs.getInt(6));
			suggestedTraining.setHasVoted("" + rs.getInt(7));
			return suggestedTraining;
		});
		return schecduledTrainings;
	}

	private List<RequestTraining> getRequests(int employeeId) {
		String sql = SqlQueryConstants.GET_REQUESTS;
		List<RequestTraining> requestTrainings = jdbcTemplate.query(sql, new Object[] { employeeId }, (rs, rowNum) -> {
			RequestTraining requestTraining = new RequestTraining();
			requestTraining.setTrainingId(rs.getInt(1));
			requestTraining.setEmployeeId(rs.getInt(2));
			requestTraining.setEmployeeName(rs.getString(3));
			requestTraining.setStatus(rs.getString(4));
			return requestTraining;
		});
		return requestTrainings;
	}

	String getTrainingLocation(String locationId) {
		String queryToGetLocation = SqlQueryConstants.GET_LOCATION;
		return jdbcTemplate.queryForObject(queryToGetLocation, new Object[] { locationId }, String.class);
	}

	Schedule getTrainingTime(String trainingId) {
		try {
			String queryToGetStartAndEndTime = SqlQueryConstants.GET_TIME;
			return jdbcTemplate.queryForObject(queryToGetStartAndEndTime, new Object[] { trainingId }, (rs, rowNum) -> {
				Schedule timeObj = new Schedule();
				timeObj.setStartDate(rs.getString(1));
				timeObj.setEndDate(rs.getString(2));
				return timeObj;
			});
		} catch (Exception e) {
			return null;
		}
	}

	private String getImageStringFromTrainingName(String courseName) {
		// StringBuffer currentPath = new
		// StringBuffer(System.getProperty("user.dir"));
		// currentPath.append("/images/" + courseName);
		String currentdir = System.getProperty("user.dir");
		String imagePath = currentdir + "/images/Java5";
		// File folder = new File(currentPath.toString());
		File folder = new File(imagePath);
		if (!folder.exists()) {
			String path = "/Users/poweruser/Documents/Default";
			folder = new File(path);
		}
		String encodedfile = null;
		try {
			@SuppressWarnings("resource")
			FileInputStream fileInputStreamReader = new FileInputStream(folder);
			byte[] bytes = new byte[(int) folder.length()];
			fileInputStreamReader.read(bytes);
			Encoder en = Base64.getEncoder();
			encodedfile = en.encodeToString(bytes);

		} catch (Exception e) {
			logger.error("error while convertion image data");
			return null;
		}

		return encodedfile;
	}
}
