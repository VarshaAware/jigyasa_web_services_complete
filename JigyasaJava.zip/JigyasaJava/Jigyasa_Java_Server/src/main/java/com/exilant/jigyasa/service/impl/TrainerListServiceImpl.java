/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 09-May-2017
  * TrainerListServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.TrainerListRepository;
import com.exilant.jigyasa.service.TrainerListService;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.Trainer;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class TrainerListServiceImpl implements TrainerListService {

	@Autowired
	TrainerListRepository trainerListRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.service.TrainerListService#getTrainerList(com.exilant
	 * .jigyasa.vo.Trainer)
	 */
	@Override
	public Map<String, List<Trainer>> getTrainerList(RequestTraining trainer) {
		Map<String, List<Trainer>> map = null;
		if (trainer != null) {
			if (trainer.getTrainerName() != null) {
				map = trainerListRepository.getTrainerList(trainer.getTrainerName());
			} else {
				map = trainerListRepository.getTrainerList();
			}
		} else {
			map = trainerListRepository.getTrainerList();
		}
		return map;
	}

}
