/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 10-May-2017
  * ReportersControllerImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.ReportersController;
import com.exilant.jigyasa.service.ReportersService;
import com.exilant.jigyasa.vo.Repotees;
import com.exilant.jigyasa.vo.RequestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@RestController
public class ReportersControllerImpl implements ReportersController {

	@Autowired
	ReportersService reportersService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.controller.ReportersController#getRepoters()
	 */
	@Override
	@RequestMapping(value = URIConstants.REPORTERS, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getRepoters(@RequestBody RequestTraining obj) throws Exception {
		List<Repotees> list = reportersService.getRepoters(obj);
		if (list != null) {
			Map<String, List<Repotees>> map = new HashMap<String, List<Repotees>>();
			map.put("repotees", list);
			return new ResponseEntity<Map<String, List<Repotees>>>(map, HttpStatus.OK);
		} else {
			Map<String, String> map = new HashMap<String, String>();
			map.put("errorMessage", "someError");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
		}
	}

}
