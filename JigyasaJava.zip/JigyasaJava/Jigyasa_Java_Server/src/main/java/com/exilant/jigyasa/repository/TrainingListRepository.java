/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository;

import java.util.List;

import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
public interface TrainingListRepository {
	TrainingListResponse getTrainingList(int employeeId, int roleId);

	TrainingListResponse getTrainingListForManager(int employeeId, int roleId);

	MyTraining getTrainingDetails(int trainingId, int employeeId);

	List<MyTraining> getTrainingHistory(int employeeId);

}
