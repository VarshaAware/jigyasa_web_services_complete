package com.exilant.jigyasa.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.AttendenceRepository;
import com.exilant.jigyasa.service.AttendenceService;
import com.exilant.jigyasa.vo.AttendanceRequest;
import com.exilant.jigyasa.vo.AttendanceResponse;
import com.exilant.jigyasa.vo.Attendees;
import com.exilant.jigyasa.vo.RequestStatus;
import com.exilant.jigyasa.vo.RequestTraining;

@Service
public class AttendenceServiceImpl implements AttendenceService {
	static final Logger logger = LoggerFactory.getLogger(AttendenceServiceImpl.class);

	@Autowired
	AttendenceRepository attendenceRepository;

	@Override
	public boolean markAttendence(RequestStatus markAttendence) {
		if (markAttendence.getTrainingId() == 0) {
			logger.error("trainingId is missing");
			return false;
		} else if (markAttendence.getEmployeeId().size() == 0) {
			logger.error("empId is missing");
			return false;
		}
		return attendenceRepository.markAttendence(markAttendence);
	}
	
	@Override
	public List<AttendanceResponse> fetchAttendence(AttendanceRequest reqObj) {
		if (reqObj.getDate().isEmpty()) {
			logger.error("Date is missing");
			return null;
		} else if (reqObj.getTrainingId() == 0) {
			logger.error("trainingId is missing");
			return null;
		}
		return attendenceRepository.fetchAttendence(reqObj.getTrainingId(), reqObj.getDate());
	}
	
	@Override
	public List<Attendees> fetchAttendeeList(RequestTraining reqObj) {
		if (reqObj.getEmployeeId() == 0) {
			logger.error("EmployeeId is missing");
			return null;
		} else if (reqObj.getTrainingId() == 0) {
			logger.error("trainingId is missing");
			return null;
		}
		return attendenceRepository.fetchAttendeeList(reqObj.getEmployeeId(), reqObj.getTrainingId());
	}
}