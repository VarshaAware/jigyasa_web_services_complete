/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 08-May-2017
  * Status.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author lakshmi.bhat
 *
 */
public class Status {
	   @JsonProperty("statusCode")
	    private String statusCode;

	    @JsonProperty("statusDesc")
	    private String statusDesc;
	    
	    public Status() {}
	    
		public Status(String statusCode, String statusDesc) {
			super();
			this.statusCode = statusCode;
			this.statusDesc = statusDesc;
		}
		/**
		 * @return the statusCode
		 */
		public String getStatusCode() {
			return statusCode;
		}

		/**
		 * @param statusCode the statusCode to set
		 */
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}

		/**
		 * @return the statusDesc
		 */
		public String getStatusDesc() {
			return statusDesc;
		}

		/**
		 * @param statusDesc the statusDesc to set
		 */
		public void setStatusDesc(String statusDesc) {
			this.statusDesc = statusDesc;
		}   
	    
}
