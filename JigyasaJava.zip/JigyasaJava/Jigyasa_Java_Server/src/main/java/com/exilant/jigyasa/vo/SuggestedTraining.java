/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 05-May-2017
  * SuggestedTraining.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author lakshmi.bhat
 *
 */
public class SuggestedTraining {
	@JsonProperty("title")
	private String courseName;
	private String courseId;
	private String suggestedBy;
	private String description;
	@JsonProperty("suggestedByEmpName")
	private String employeeName;
	private String votes;
	private String hasVoted;

	public SuggestedTraining() {
	}

	public SuggestedTraining(String courseName, String courseId, String suggestedBy, String description,
			String employeeName, String votes, String hasVoted) {
		super();
		this.courseName = courseName;
		this.courseId = courseId;
		this.suggestedBy = suggestedBy;
		this.description = description;
		this.employeeName = employeeName;
		this.votes = votes;
		this.hasVoted = hasVoted;
	}

	/**
	 * @return the courseName
	 */
	public String getCourseName() {
		return courseName;
	}

	/**
	 * @param courseName
	 *            the courseName to set
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	/**
	 * @return the courseId
	 */
	public String getCourseId() {
		return courseId;
	}

	/**
	 * @param courseId
	 *            the courseId to set
	 */
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	/**
	 * @return the suggestedBy
	 */
	public String getSuggestedBy() {
		return suggestedBy;
	}

	/**
	 * @param suggestedBy
	 *            the suggestedBy to set
	 */
	public void setSuggestedBy(String suggestedBy) {
		this.suggestedBy = suggestedBy;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName
	 *            the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the votes
	 */
	public String getVotes() {
		return votes;
	}

	/**
	 * @param votes
	 *            the votes to set
	 */
	public void setVotes(String votes) {
		this.votes = votes;
	}

	/**
	 * @return the hasVoted
	 */
	public String getHasVoted() {
		return hasVoted;
	}

	/**
	 * @param hasVoted
	 *            the hasVoted to set
	 */
	public void setHasVoted(String hasVoted) {
		this.hasVoted = hasVoted;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SuggestedTraining [courseName=" + courseName + ", courseId=" + courseId + ", suggestedBy=" + suggestedBy
				+ ", description=" + description + ", employeeName=" + employeeName + ", votes=" + votes + ", hasVoted="
				+ hasVoted + "]";
	}

}
