package com.exilant.jigyasa.service;

import com.exilant.jigyasa.vo.TrainingList;

public interface VoteForTrainingService {
	Boolean voteForTraining(TrainingList voteForTraining);
}
