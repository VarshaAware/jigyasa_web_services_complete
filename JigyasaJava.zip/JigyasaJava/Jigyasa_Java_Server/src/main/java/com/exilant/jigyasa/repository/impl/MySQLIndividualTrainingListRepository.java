/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * MySQLTrainingListRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.IndividualTrainingListRepository;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.Schedule;
import com.exilant.jigyasa.vo.Scheduled_Training;
import com.exilant.jigyasa.vo.SuggestedTraining;
import com.exilant.jigyasa.vo.Training;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLIndividualTrainingListRepository implements IndividualTrainingListRepository {
	static final Logger logger = LoggerFactory.getLogger(MySQLIndividualTrainingListRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	TrainingListResponse trainingList = null;
	MyTraining trainingDetail = null;

	@Override
	public List<MyTraining> getMyTrainingList(int employeeId, int roleId) {
		trainingList = new TrainingListResponse();

		try {
			List<MyTraining> myTrainingList = getMyTrainings(employeeId);

			return myTrainingList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<MyTraining> getUpcomingTrainingList(int employeeId, int roleId) {
		trainingList = new TrainingListResponse();

		try {
			List<MyTraining> allTrainingList = getAllTrainings(roleId);

			return allTrainingList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<SuggestedTraining> getSuggestedTrainingList(int employeeId, int roleId) {
		trainingList = new TrainingListResponse();

		try {
			List<SuggestedTraining> suggestedTainingList = getSuggestedTainings(employeeId);

			return suggestedTainingList;
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	public List<MyTraining> getTodayTrainingList(int employeeId, int roleId) {
		trainingList = new TrainingListResponse();

		try {
			List<MyTraining> todayTrainingList = getTodayTrainingList();

			return todayTrainingList;
		} catch (Exception e) {
			return null;
		}
	}

	private List<MyTraining> getMyTrainings(int employeeId) {
		List<MyTraining> myTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dateFormat.format(new Date());
		String declined = "Declined";

		String sqlToGetMyTrainingId = SqlQueryConstants.GET_TRAINING_ID_FOR_MY_TRAINING;
		Object[] queryParameters = new Object[] { employeeId, declined, date };
		List<String> myTrainingId = jdbcTemplate.query(sqlToGetMyTrainingId, queryParameters,
				(rs, rowNum) -> rs.getInt(1) + "");

		String approved = "Approved";
		String sqlToGetMyTrainingId1 = SqlQueryConstants.GET_TRAINING_ID_FOR_STATUS_APPROVED;
		Object[] queryParameters1 = new Object[] { employeeId, approved, date };
		List<String> myTrainingId1 = jdbcTemplate.query(sqlToGetMyTrainingId1, queryParameters1,
				(rs, rowNum) -> rs.getInt(1) + "");
		for (String val : myTrainingId1) {
			myTrainingId.add(val);
		}
		if (myTrainingId.size() > 0) {
			for (String i : myTrainingId) {
				String sql = SqlQueryConstants.GET_IDS;
				Scheduled_Training schecduledTraining = jdbcTemplate.queryForObject(sql, new Object[] { i },
						(rs, rowNum) -> {
							Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
							schecduledTrainingObj.setCourseId(rs.getInt(1) + "");
							schecduledTrainingObj.setTrainingLocationId(rs.getInt(2) + "");
							schecduledTrainingObj.setSeats(rs.getInt(3) + "");
							return schecduledTrainingObj;
						});

				Training course = null;
				if (!schecduledTraining.getCourseId().isEmpty()) {
					course = getCourseObject(schecduledTraining.getCourseId());
				}

				String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

				Schedule time = getTrainingTime(i);

				MyTraining myTraining = new MyTraining();
				myTraining.setLocation(trainingRoom);
				myTraining.setEndDateTime(time.getEndDate());
				String courseName = getImageStringFromTrainingName(course.getTitle());
				myTraining.setImage(courseName);
				myTraining.setTrainingId(i);
				myTraining.setDescription(course.getDescription());
				myTraining.setTitle(course.getTitle());
				myTraining.setStartDateTime(time.getStartDate());
				myTraining.setSeats(schecduledTraining.getSeats());
				myTraining.setLink(course.getLink());
				myTrainings.add(myTraining);
			}
		}
		return myTrainings;
	}

	private List<MyTraining> getAllTrainings(int roleId) {
		List<MyTraining> allTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dateFormat.format(new Date());

		String sql = SqlQueryConstants.GET_IDS_FOR_ALL_TRAINING;
		List<Scheduled_Training> schecduledTrainings = jdbcTemplate.query(sql, new Object[] { date }, (rs, rowNum) -> {
			Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
			schecduledTrainingObj.setScheduled_Training_Id(rs.getInt(1) + "");
			schecduledTrainingObj.setCourseId(rs.getInt(2) + "");
			schecduledTrainingObj.setTrainingLocationId(rs.getInt(3) + "");
			schecduledTrainingObj.setSeats("" + rs.getInt(4));
			return schecduledTrainingObj;
		});
		if (schecduledTrainings.size() > 0) {
			for (Scheduled_Training schecduledTraining : schecduledTrainings) {
				String drafted = "Drafted";
				String deleted = "Deleted";
				Training course = null;
				try {
					if (roleId == 1) {
						course = getCourseObject(schecduledTraining.getCourseId());
					} else {
						String queryToGetCourse = SqlQueryConstants.GET_COURSEDETAIL_ON_STATE;
						Object[] queryParameters = new Object[] { schecduledTraining.getCourseId(), drafted, deleted };
						course = jdbcTemplate.queryForObject(queryToGetCourse, queryParameters, (rs, rowNum) -> {
							Training courseObj = new Training();
							courseObj.setTitle(rs.getString(1));
							courseObj.setState(rs.getString(2));
							courseObj.setImage(rs.getString(3));
							return courseObj;
						});
					}
				} catch (EmptyResultDataAccessException e) {
					return null;
				}
				String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

				Schedule time = getTrainingTime(schecduledTraining.getScheduled_Training_Id());

				MyTraining allTraining = new MyTraining();
				allTraining.setLocation(trainingRoom);
				allTraining.setEndDateTime(time.getEndDate());
				String courseName = getImageStringFromTrainingName(course.getTitle());
				allTraining.setImage(courseName);
				allTraining.setTrainingId("" + schecduledTraining.getScheduled_Training_Id());
				allTraining.setTitle(course.getTitle());
				allTraining.setStartDateTime(time.getStartDate());
				if (schecduledTraining.getSeats().isEmpty()) {
					allTraining.setSeats("");
				} else {
					allTraining.setSeats(schecduledTraining.getSeats());
				}
				allTraining.setLink(course.getLink());
				allTrainings.add(allTraining);
			}
		}
		return allTrainings;
	}

	private List<MyTraining> getTodayTrainingList() {
		List<MyTraining> todayTrainings = new ArrayList<MyTraining>();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String date = dateFormat.format(new Date());

		String sql = SqlQueryConstants.GET_IDS_FOR_TODAY_TRAINING;
		List<Scheduled_Training> schecduledTrainings = jdbcTemplate.query(sql, new Object[] { date }, (rs, rowNum) -> {
			Scheduled_Training schecduledTrainingObj = new Scheduled_Training();
			schecduledTrainingObj.setScheduled_Training_Id(rs.getInt(1) + "");
			schecduledTrainingObj.setCourseId(rs.getInt(2) + "");
			schecduledTrainingObj.setTrainingLocationId(rs.getInt(3) + "");
			schecduledTrainingObj.setSeats(rs.getInt(4) + "");
			return schecduledTrainingObj;
		});
		if (schecduledTrainings.size() > 0) {
			for (Scheduled_Training schecduledTraining : schecduledTrainings) {
				Training course = getCourseObject(schecduledTraining.getCourseId());

				String trainingRoom = getTrainingLocation(schecduledTraining.getTrainingLocationId());

				Schedule time = getTrainingTime(schecduledTraining.getScheduled_Training_Id());

				MyTraining todayTraining = new MyTraining();
				todayTraining.setLocation(trainingRoom);
				todayTraining.setEndDateTime(time.getEndDate());
				String courseName = getImageStringFromTrainingName(course.getTitle());
				todayTraining.setImage(courseName);
				todayTraining.setTrainingId("" + schecduledTraining.getScheduled_Training_Id());
				todayTraining.setDescription(course.getDescription());
				todayTraining.setTitle(course.getTitle());
				todayTraining.setStartDateTime(time.getStartDate());
				todayTraining.setSeats(schecduledTraining.getSeats());
				todayTraining.setLink(course.getLink());
				todayTrainings.add(todayTraining);
			}
		}
		return todayTrainings;
	}

	private List<SuggestedTraining> getSuggestedTainings(int employeeId) {
		String deleted = "Deleted";
		String suggested = "Suggested";
		String sql = SqlQueryConstants.GET_COURSE_DETAIL_FOR_SUGGESTED_TRAINING;
		Object[] queryParameters = new Object[] { employeeId, deleted, suggested };
		List<SuggestedTraining> schecduledTrainings = jdbcTemplate.query(sql, queryParameters, (rs, rowNum) -> {
			SuggestedTraining suggestedTraining = new SuggestedTraining();
			suggestedTraining.setCourseName(rs.getString(1));
			suggestedTraining.setCourseId("" + rs.getInt(2));
			suggestedTraining.setSuggestedBy(rs.getString(3));
			suggestedTraining.setDescription(rs.getString(4));
			suggestedTraining.setEmployeeName(rs.getString(5));
			suggestedTraining.setVotes("" + rs.getInt(6));
			suggestedTraining.setHasVoted("" + rs.getInt(7));
			return suggestedTraining;
		});
		return schecduledTrainings;
	}

	private Training getCourseObject(String courseId) {
		try {
			String queryToGetCourse = SqlQueryConstants.GET_COURSE_OBJECT;
			Object[] queryParameters = new Object[] { courseId };
			Training course = jdbcTemplate.queryForObject(queryToGetCourse, queryParameters, (rs, rowNum) -> {
				Training courseObj = new Training();
				courseObj.setTitle(rs.getString(1));
				courseObj.setImage(rs.getString(2));
				courseObj.setDescription(rs.getString(3));
				courseObj.setLink(rs.getString(4));
				return courseObj;
			});
			return course;
		} catch (Exception e) {
			return null;
		}
	}

	String getTrainingLocation(String locationId) {
		String queryToGetLocation = SqlQueryConstants.GET_LOCATION;
		return jdbcTemplate.queryForObject(queryToGetLocation, new Object[] { locationId }, String.class);
	}

	Schedule getTrainingTime(String trainingId) {
		try {
			String queryToGetStartAndEndTime = SqlQueryConstants.GET_TIME;
			return jdbcTemplate.queryForObject(queryToGetStartAndEndTime, new Object[] { trainingId }, (rs, rowNum) -> {
				Schedule timeObj = new Schedule();
				timeObj.setStartDate(rs.getString(1));
				timeObj.setEndDate(rs.getString(2));
				return timeObj;
			});
		} catch (Exception e) {
			return null;
		}
	}

	private String getImageStringFromTrainingName(String courseName) {
		// StringBuffer currentPath = new
		// StringBuffer(System.getProperty("user.dir"));
		// currentPath.append("/images/" + courseName);
		String currentdir = System.getProperty("user.dir");
		String imagePath = currentdir + "/images/Java5";
		// File folder = new File(currentPath.toString());
		File folder = new File(imagePath);
		if (!folder.exists()) {
			String path = "/Users/poweruser/Documents/Default";
			folder = new File(path);
		}
		String encodedfile = null;
		try {
			@SuppressWarnings("resource")
			FileInputStream fileInputStreamReader = new FileInputStream(folder);
			byte[] bytes = new byte[(int) folder.length()];
			fileInputStreamReader.read(bytes);
			Encoder en = Base64.getEncoder();
			encodedfile = en.encodeToString(bytes);

		} catch (Exception e) {
			logger.error("error while convertion image data");
			return null;
		}

		return encodedfile;
	}
}
