package com.exilant.jigyasa.service;

import java.util.List;

import com.exilant.jigyasa.vo.AttendanceRequest;
import com.exilant.jigyasa.vo.AttendanceResponse;
import com.exilant.jigyasa.vo.Attendees;
import com.exilant.jigyasa.vo.RequestStatus;
import com.exilant.jigyasa.vo.RequestTraining;

public interface AttendenceService {
	boolean markAttendence(RequestStatus markAttendence);

	/**
	 * @param reqObj
	 * @return
	 */
	List<AttendanceResponse> fetchAttendence(AttendanceRequest reqObj);

	/**
	 * @param reqObj
	 * @return
	 */
	List<Attendees> fetchAttendeeList(RequestTraining reqObj);

}
