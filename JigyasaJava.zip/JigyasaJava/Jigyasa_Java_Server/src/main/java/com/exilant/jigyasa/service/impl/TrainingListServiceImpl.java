/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.TrainingListRepository;
import com.exilant.jigyasa.service.TrainingListService;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.TrainingList;
import com.exilant.jigyasa.vo.TrainingListResponse;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class TrainingListServiceImpl implements TrainingListService {
	static final Logger logger = LoggerFactory.getLogger(TrainingListServiceImpl.class);

	@Autowired
	TrainingListRepository trainingListRepository;

	TrainingListResponse result = new TrainingListResponse();

	@Override
	public TrainingListResponse getTrainingList(TrainingList trainingList) {
		if (trainingList.getEmployeeId() == 0) {
			logger.error("Employee Id is missing");
		} else {
			if (trainingList.getDesignation() == 2) {
				result = trainingListRepository.getTrainingListForManager(trainingList.getEmployeeId(),
						trainingList.getDesignation());
			} else {
				result = trainingListRepository.getTrainingList(trainingList.getEmployeeId(),
						trainingList.getDesignation());
			}
		}
		return result;
	}

	@Override
	public MyTraining getTrainingDetails(TrainingList trainingList) {
		if (trainingList.getTrainingId() == 0) {
			logger.error("Training Id is missing");
			return null;
		}
		return trainingListRepository.getTrainingDetails(trainingList.getTrainingId(), trainingList.getEmployeeId());
	}
	
	@Override
	public List<MyTraining> getTrainingHistory(TrainingList trainingList){
		if(trainingList == null){
			return trainingListRepository.getTrainingHistory(0);
		}else
		return trainingListRepository.getTrainingHistory(trainingList.getEmployeeId());
	}
}
