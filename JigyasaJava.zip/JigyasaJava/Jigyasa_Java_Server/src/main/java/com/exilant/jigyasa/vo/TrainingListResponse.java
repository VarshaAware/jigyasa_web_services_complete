/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 05-May-2017
  * AdminTraining.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import java.util.List;

/**
 * @author lakshmi.bhat
 *
 */
public class TrainingListResponse {
	private List<MyTraining> myTrainings;
	private List<MyTraining> todayTrainings;
	private List<SuggestedTraining> trainingSuggestions;
	private List<RequestTraining> request;
	private List<MyTraining> upComingTrainings;

	public TrainingListResponse() {
	}

	public TrainingListResponse(List<MyTraining> upComingTrainings, List<MyTraining> myTrainings,
			List<MyTraining> todayTrainings, List<SuggestedTraining> trainingSuggestions,
			List<RequestTraining> request) {
		super();
		this.upComingTrainings = upComingTrainings;
		this.myTrainings = myTrainings;
		this.todayTrainings = todayTrainings;
		this.trainingSuggestions = trainingSuggestions;
		this.request = request;
	}

	/**
	 * @return the request
	 */
	public List<RequestTraining> getRequest() {
		return request;
	}

	/**
	 * @param request
	 *            the request to set
	 */
	public void setRequest(List<RequestTraining> request) {
		this.request = request;
	}

	/**
	 * @return the upcomingTrainings
	 */
	public List<MyTraining> getUpComingTrainings() {
		return upComingTrainings;
	}

	/**
	 * @param upcomingTrainings
	 *            the upcomingTrainings to set
	 */
	public void setUpComingTrainings(List<MyTraining> upComingTrainings) {
		this.upComingTrainings = upComingTrainings;
	}

	/**
	 * @return the myTrainings
	 */
	public List<MyTraining> getMyTrainings() {
		return myTrainings;
	}

	/**
	 * @param myTrainings
	 *            the myTrainings to set
	 */
	public void setMyTrainings(List<MyTraining> myTrainings) {
		this.myTrainings = myTrainings;
	}

	/**
	 * @return the todayTrainings
	 */
	public List<MyTraining> getTodayTrainings() {
		return todayTrainings;
	}

	/**
	 * @param todayTrainings
	 *            the todayTrainings to set
	 */
	public void setTodayTrainings(List<MyTraining> todayTrainings) {
		this.todayTrainings = todayTrainings;
	}

	/**
	 * @return the trainingSuggestions
	 */
	public List<SuggestedTraining> getTrainingSuggestions() {
		return trainingSuggestions;
	}

	/**
	 * @param trainingSuggestions
	 *            the trainingSuggestions to set
	 */
	public void setTrainingSuggestions(List<SuggestedTraining> trainingSuggestions) {
		this.trainingSuggestions = trainingSuggestions;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TrainingListResponse [upcomingTrainings=" + upComingTrainings + ", myTrainings=" + myTrainings
				+ ", todayTrainings=" + todayTrainings + ", trainingSuggestions=" + trainingSuggestions + ", request="
				+ request + "]";
	}

}
