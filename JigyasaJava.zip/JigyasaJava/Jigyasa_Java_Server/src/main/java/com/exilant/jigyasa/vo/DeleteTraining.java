/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 23-May-2017
>  * DeleteTraining.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

/**
 * @author swathi.m
 *
 */
public class DeleteTraining {
private int courseId;

public DeleteTraining() {
	super();
}

public DeleteTraining(int courseId) {
	super();
	this.courseId = courseId;
}

public int getCourseId() {
	return courseId;
}

public void setCourseId(int courseId) {
	this.courseId = courseId;
}

@Override
public String toString() {
	return "DeleteTraining [courseId=" + courseId + "]";
}

}
