/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * GetManagerListServiceImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.GetManagerListRepository;
import com.exilant.jigyasa.service.GetManagerListService;
import com.exilant.jigyasa.vo.ManagerList;

/**
 * @author swathi.m
 *
 */
@Service
public class GetManagerListServiceImpl implements GetManagerListService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.service.GetManagerListService#getManagerList(com.
	 * exilant.jigyasa.vo.ManagerList)
	 */

	@Autowired
	GetManagerListRepository getManagerListRepository;

	@Override
	public List<ManagerList> getManagerList(ManagerList managerList) {
		// TODO Auto-generated method stub
		List<ManagerList> managersList = new ArrayList<ManagerList>();
		managersList = getManagerListRepository.getManagerList();
		return managersList;
	}

}
