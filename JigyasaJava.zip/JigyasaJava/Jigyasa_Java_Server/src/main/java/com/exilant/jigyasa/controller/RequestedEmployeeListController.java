package com.exilant.jigyasa.controller;

import org.springframework.http.ResponseEntity;

import com.exilant.jigyasa.vo.RequestTraining;

public interface RequestedEmployeeListController {
	ResponseEntity<?> getRequestedEmployeeList(RequestTraining requestedEmployeeList) throws Exception;
}
