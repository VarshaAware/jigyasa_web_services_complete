package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.RequestTraining;

public interface RequestTrainingRepository {
	String scheduledTraining(RequestTraining scheduledTrainingRequest);
}
