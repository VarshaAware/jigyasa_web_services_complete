/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 08-May-2017
>  * UpdateTrainingRepository.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.CreateNewTraining;

/**
 * @author swathi.m
 *
 */
public interface UpdateTrainingRepository {
	int updateTraining(CreateNewTraining updateTraining);
}
