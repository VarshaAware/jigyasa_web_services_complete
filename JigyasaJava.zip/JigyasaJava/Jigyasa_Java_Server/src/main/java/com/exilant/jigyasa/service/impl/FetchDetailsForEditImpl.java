/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 17-May-2017
>  * FetchDetailsForEditImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.FetchDetailsforEditRepository;
import com.exilant.jigyasa.service.FetchDetailsForEditService;
import com.exilant.jigyasa.vo.FetchDetailForEdit;
import com.exilant.jigyasa.vo.Training;

/**
 * @author swathi.m
 *
 */
@Service
public class FetchDetailsForEditImpl implements FetchDetailsForEditService {

	@Autowired
	FetchDetailsforEditRepository fetchDetailsForEditRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.service.FetchDetailsForEditService#
	 * fetchDetailsForEditService(com.exilant.jigyasa.vo.Training)
	 */
	@Override
	public FetchDetailForEdit fetchDetailsForEditService(Training training) {
		// TODO Auto-generated method stub
		FetchDetailForEdit detailsForEdit = fetchDetailsForEditRepository.fetchDetailsForEdit(training);
		return detailsForEdit;
	}

}
