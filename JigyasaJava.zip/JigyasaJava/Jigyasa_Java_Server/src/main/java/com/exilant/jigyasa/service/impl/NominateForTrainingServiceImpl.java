/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 28-Apr-2017
  * NominateForTrainingServiceImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.NominateForTrainingRepository;
import com.exilant.jigyasa.service.NominateForTrainingService;
import com.exilant.jigyasa.vo.ScheduledTrainingNominee;
import com.exilant.jigyasa.vo.SuggestTraining;

/**
 * @author lakshmi.bhat
 *
 */
@Service
public class NominateForTrainingServiceImpl implements NominateForTrainingService {
	static final Logger logger = LoggerFactory.getLogger(NominateForTrainingServiceImpl.class);

	@Autowired
	NominateForTrainingRepository nominateForTrainingRepository;

	@Override
	public List<?> nominateEmp(ScheduledTrainingNominee nominee) {
		if (nominee.getEmployeeId() == 0) {
			logger.error("employeeId is missing");
		} else if (nominee.getTrainingId() == 0) {
			logger.error("trainingId is missing");
		} else if (nominee.getNomineeId().size() == 0) {
			logger.error("nomineeId is missing");
		}
		return nominateForTrainingRepository.nominateEmp(nominee);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.service.NominateForTrainingService#
	 * selfDeclineNomination(com.exilant.jigyasa.vo.SuggestedTraining)
	 */
	@Override
	public boolean selfDeclineNomination(SuggestTraining trainingObj) {
		if (trainingObj.getEmployeeId() == 0) {
			logger.error("employeeId is missing");
			return false;
		} else if (trainingObj.getTrainingId() == 0) {
			logger.error("trainingId is missing");
			return false;
		} else if (trainingObj.getDescription().length() >= 225) {
			logger.error("Reason For Declining training should not be more than 225");
			return false;
		}
		return nominateForTrainingRepository.selfDeclineNomination(trainingObj.getEmployeeId(),
				trainingObj.getTrainingId(), trainingObj.getDescription());
	}

}
