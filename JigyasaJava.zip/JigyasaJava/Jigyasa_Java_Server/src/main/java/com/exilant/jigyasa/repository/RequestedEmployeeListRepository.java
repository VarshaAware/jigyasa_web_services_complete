package com.exilant.jigyasa.repository;

import java.util.List;

import com.exilant.jigyasa.vo.RequestedEmployeeList;

public interface RequestedEmployeeListRepository {

	List<RequestedEmployeeList> getRequestedEmployeeList(int employeeId, int trainingId);
}
