/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 17-May-2017
>  * FetchDetailForEdit.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author swathi.m
 *
 */
public class FetchDetailForEdit {
	@JsonProperty("notification")
	private FetchNotification fetchNotification;
	private String link;
	private int courseId;
	private String courseDescription;
	private List<String> trainerId;

	public FetchDetailForEdit() {
		super();
	}

	public FetchDetailForEdit(FetchNotification fetchNotification, String link, int courseId, String courseDescription,
			List<String> trainerId) {
		super();
		this.fetchNotification = fetchNotification;
		this.link = link;
		this.courseId = courseId;
		this.courseDescription = courseDescription;
		this.trainerId = trainerId;
	}

	public FetchNotification getFetchNotification() {
		return fetchNotification;
	}

	public void setFetchNotification(FetchNotification fetchNotification) {
		this.fetchNotification = fetchNotification;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseDescription() {
		return courseDescription;
	}

	public void setCourseDescription(String courseDescription) {
		this.courseDescription = courseDescription;
	}

	public List<String> getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(List<String> trainerId) {
		this.trainerId = trainerId;
	}

	@Override
	public String toString() {
		return "FetchDetailForEdit [fetchNotification=" + fetchNotification + ", link=" + link + ", courseId="
				+ courseId + ", courseDescription=" + courseDescription + ", trainerId=" + trainerId + "]";
	}

}
