/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * TrainerList.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

/**
 * @author swathi.m
 *
 */
public class TrainerList {
private String employeeId;

public TrainerList() {
	super();
}

public TrainerList(String employeeId) {
	super();
	this.employeeId = employeeId;
}

public String getEmployeeId() {
	return employeeId;
}

public void setEmployeeId(String employeeId) {
	this.employeeId = employeeId;
}

@Override
public String toString() {
	return "TrainerList [employeeId=" + employeeId + "]";
}

}
