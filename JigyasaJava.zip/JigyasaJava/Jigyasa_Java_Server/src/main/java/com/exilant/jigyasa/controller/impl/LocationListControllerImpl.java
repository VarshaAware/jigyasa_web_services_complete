package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.LocationListController;
import com.exilant.jigyasa.service.LocationListService;
import com.exilant.jigyasa.vo.TrainingLocation;

@RestController
public class LocationListControllerImpl implements LocationListController {

	@Autowired
	LocationListService locationListService;

	@Override
	@RequestMapping(value = URIConstants.LOCATION_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getLocationList(@RequestBody(required = false) TrainingLocation location)
			throws Exception {

		List<TrainingLocation> locationList = locationListService.getlocationList(location);
		if (locationList != null) {
			Map<String, List<TrainingLocation>> map = new HashMap<String, List<TrainingLocation>>();
			map.put("locations", locationList);
			return new ResponseEntity<Map<String, List<TrainingLocation>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("locations", "no location");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);
	}
}