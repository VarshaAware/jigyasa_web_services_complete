/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 17-May-2017
>  * FetchNotification.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.vo;

import java.util.List;

/**
 * @author swathi.m
 *
 */
public class FetchNotification {
	private String mailNotificationtype;
	private String mailNotificationRcpType;
	private List<String> managerId;
	private String mailNotificationContent;

	public FetchNotification() {
		super();
	}

	public FetchNotification(String mailNotificationtype, String mailNotificationRcpType, List<String> managerId,
			String mailNotificationContent) {
		super();
		this.mailNotificationtype = mailNotificationtype;
		this.mailNotificationRcpType = mailNotificationRcpType;
		this.managerId = managerId;
		this.mailNotificationContent = mailNotificationContent;
	}

	public String getMailNotificationtype() {
		return mailNotificationtype;
	}

	public void setMailNotificationtype(String mailNotificationtype) {
		this.mailNotificationtype = mailNotificationtype;
	}

	public String getMailNotificationRcpType() {
		return mailNotificationRcpType;
	}

	public void setMailNotificationRcpType(String mailNotificationRcpType) {
		this.mailNotificationRcpType = mailNotificationRcpType;
	}

	public List<String> getManagerId() {
		return managerId;
	}

	public void setManagerId(List<String> managerId) {
		this.managerId = managerId;
	}

	public String getMailNotificationContent() {
		return mailNotificationContent;
	}

	public void setMailNotificationContent(String mailNotificationContent) {
		this.mailNotificationContent = mailNotificationContent;
	}

	@Override
	public String toString() {
		return "FetchNotification [mailNotificationtype=" + mailNotificationtype + ", mailNotificationRcpType="
				+ mailNotificationRcpType + ", managerId=" + managerId + ", mailNotificationContent="
				+ mailNotificationContent + "]";
	}

}
