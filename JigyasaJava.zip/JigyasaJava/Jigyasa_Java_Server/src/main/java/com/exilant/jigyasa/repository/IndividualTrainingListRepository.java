/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository;

import java.util.List;

import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.SuggestedTraining;

/**
 * @author lakshmi.bhat
 *
 */
public interface IndividualTrainingListRepository {

	/**
	 * @param employeeId
	 * @param roleId
	 * @return
	 */
	List<MyTraining> getMyTrainingList(int employeeId, int roleId);

	/**
	 * @param employeeId
	 * @param roleId
	 * @return
	 */
	List<MyTraining> getTodayTrainingList(int employeeId, int roleId);

	/**
	 * @param employeeId
	 * @param roleId
	 * @return
	 */
	List<MyTraining> getUpcomingTrainingList(int employeeId, int roleId);

	/**
	 * @param employeeId
	 * @param roleId
	 * @return
	 */
	List<SuggestedTraining> getSuggestedTrainingList(int employeeId, int roleId);
}
