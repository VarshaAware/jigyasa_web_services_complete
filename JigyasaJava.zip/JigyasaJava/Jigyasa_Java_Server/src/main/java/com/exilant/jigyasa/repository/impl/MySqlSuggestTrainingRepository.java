package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.SuggestTrainingRepository;
import com.exilant.jigyasa.vo.SuggestTraining;

@Repository
public class MySqlSuggestTrainingRepository implements SuggestTrainingRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlSuggestTrainingRepository.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean suggestTraining(SuggestTraining suggestTrainingRequest) {

		try {
			String sql = SqlQueryConstants.INSERT_SUGGEST_TRAINING;
			Object[] queryParameters = new Object[] { suggestTrainingRequest.getTitle(),
					suggestTrainingRequest.getDescription(), suggestTrainingRequest.getEmployeeId() };

			jdbcTemplate.update(sql, queryParameters);

			return true;
		} catch (Exception e) {
			logger.error("Insertion failed");
			return false;
		}

	}

}
