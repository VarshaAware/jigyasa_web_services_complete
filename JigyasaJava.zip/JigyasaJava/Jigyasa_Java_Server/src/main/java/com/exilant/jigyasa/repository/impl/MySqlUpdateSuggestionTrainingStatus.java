package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.UpdateSuggestionTrainingStatusRepository;
import com.exilant.jigyasa.vo.SuggestTraining;

@Repository
public class MySqlUpdateSuggestionTrainingStatus implements UpdateSuggestionTrainingStatusRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlUpdateSuggestionTrainingStatus.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean updateSuggestionTrainingStatus(SuggestTraining updateSuggestionTrainingStatus) {

		try {
			String sql = SqlQueryConstants.UPDATE_SCHEDULED_TRAINING_STATUS;
			Object[] queryParameters = null;
			// if (updateSuggestionTrainingStatus.getStatus().equals("Created"))
			// {
			// queryParameters = new Object[] {
			// "Created",updateSuggestionTrainingStatus.getTitle(),
			// updateSuggestionTrainingStatus.getEmployeeId() };
			// } else {
			//
			// queryParameters = new Object[] {
			// "Rejected",updateSuggestionTrainingStatus.getTitle(),
			// updateSuggestionTrainingStatus.getEmployeeId() };
			// }
			queryParameters = new Object[] { updateSuggestionTrainingStatus.getStatus(),
					updateSuggestionTrainingStatus.getTitle(), updateSuggestionTrainingStatus.getEmployeeId() };
			jdbcTemplate.update(sql, queryParameters);
			return true;
		} catch (Exception e) {
			logger.error("Updation failed");
			return false;
		}

	}

}
