/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 09-May-2017
  * MySQLTrainerListRepository.java
  *
  *******************************************************/

package com.exilant.jigyasa.repository.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.TrainerListRepository;
import com.exilant.jigyasa.vo.Trainer;

/**
 * @author lakshmi.bhat
 *
 */
@Repository
public class MySQLTrainerListRepository implements TrainerListRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.repository.TrainerListRepository#getTrainerList()
	 */
	@Override
	public Map<String,List<Trainer>> getTrainerList() {
		Map<String,List<Trainer>> map = new HashMap<String, List<Trainer>>();
		try {
			String sql = SqlQueryConstants.GET_TRAINERS;
			List<Trainer> trainerList = jdbcTemplate.query(sql, (rs, rowNum) -> {
				Trainer trainer = new Trainer();
				trainer.setEmployeeId("" + rs.getInt(1));
				trainer.setEmployeeName(rs.getString(2));
				return trainer;
			});
			String queryToGetOtherEmployees = SqlQueryConstants.OTHER_EMPLOYEE_LIST;
			List<Trainer> otherList = jdbcTemplate.query(queryToGetOtherEmployees, (rs, rowNum) -> {
				Trainer trainer = new Trainer();
				trainer.setEmployeeId("" + rs.getInt(1));
				trainer.setEmployeeName(rs.getString(2));
				return trainer;
			});
			map.put("trainerList", trainerList);
			map.put("otherEmployeeList", otherList);
			return map;
		} catch (Exception e) {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.repository.TrainerListRepository#getTrainerList(java.
	 * lang.String)
	 */
	@Override
	public Map<String,List<Trainer>> getTrainerList(String trainerName) {
		Map<String,List<Trainer>> map = new HashMap<String, List<Trainer>>();
		try {
			String sql = SqlQueryConstants.GET_EMPLOYEE;
			List<Trainer> trainerList = jdbcTemplate.query(sql, new Object[] { trainerName }, (rs, rowNum) -> {
				Trainer trainer = new Trainer();
				trainer.setEmployeeId("" + rs.getInt(1));
				trainer.setEmployeeName(rs.getString(2));
				return trainer;
			});
			map.put("trainerList", trainerList);
			return map;
		} catch (Exception e) {
			return null;
		}
	}

}
