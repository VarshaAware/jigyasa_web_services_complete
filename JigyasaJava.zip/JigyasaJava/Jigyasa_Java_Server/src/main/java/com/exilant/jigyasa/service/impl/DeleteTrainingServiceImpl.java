/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 22-May-2017
>  * DeleteTrainingServiceImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exilant.jigyasa.repository.DeleteTrainingRepository;
import com.exilant.jigyasa.service.DeleteTrainingService;
import com.exilant.jigyasa.vo.DeleteTraining;

/**
 * @author swathi.m
 *
 */
@Service
public class DeleteTrainingServiceImpl implements DeleteTrainingService {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.exilant.jigyasa.service.DeleteTrainingService#deleteTrainingService(
	 * com.exilant.jigyasa.vo.SuggestTraining)
	 */

	@Autowired
	DeleteTrainingRepository deleteTrainingRepository;

	@Override
	public int deleteTrainingService(DeleteTraining deleteTrainingService) {
		// TODO Auto-generated method stub

		return deleteTrainingRepository.deleteTraining(deleteTrainingService);

	}

}
