/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 04-May-2017
  * TrainingListControllerImpl.java
  *
  *******************************************************/

package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.IndividualTrainingListController;
import com.exilant.jigyasa.service.IndividualTrainingListService;
import com.exilant.jigyasa.vo.MyTraining;
import com.exilant.jigyasa.vo.SuggestedTraining;
import com.exilant.jigyasa.vo.TrainingList;

/**
 * @author lakshmi.bhat
 *
 */
@Controller
public class IndividualTrainingListControllerImpl implements IndividualTrainingListController {

	@Autowired
	IndividualTrainingListService trainingListService;

	@Override
	@RequestMapping(value = URIConstants.MY_TRAINING_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getMyTrainingList(@RequestBody TrainingList trainingList) throws Exception {
		List<MyTraining> result = trainingListService.getMyTrainingList(trainingList);
		if (result != null) {
			Map<String, List<MyTraining>> map = new HashMap<String, List<MyTraining>>();
			map.put("myTrainings", result);
			return new ResponseEntity<Map<String, List<MyTraining>>>(map, HttpStatus.OK);
		}
		Map<String, List<MyTraining>> map = new HashMap<String, List<MyTraining>>();
		map.put("myTrainings", result);
		return new ResponseEntity<Map<String, List<MyTraining>>>(map, HttpStatus.OK);
	}

	@Override
	@RequestMapping(value = URIConstants.TODAY_TRAINING_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getTodayTrainingList(@RequestBody TrainingList trainingList) throws Exception {
		List<MyTraining> result = trainingListService.getTodayTrainingList(trainingList);
		if (result != null) {
			Map<String, List<MyTraining>> map = new HashMap<String, List<MyTraining>>();
			map.put("todayTrainings", result);
			return new ResponseEntity<Map<String, List<MyTraining>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("errorMessage", "Send proper request body");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
	}

	@Override
	@RequestMapping(value = URIConstants.UPCOMING_TRAINING_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getUpcomingTrainingList(@RequestBody TrainingList trainingList) throws Exception {
		List<MyTraining> result = trainingListService.getUpcomingTrainingList(trainingList);
		if (result != null) {
			Map<String, List<MyTraining>> map = new HashMap<String, List<MyTraining>>();
			map.put("upComingTrainings", result);
			return new ResponseEntity<Map<String, List<MyTraining>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("errorMessage", "Send proper request body");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
	}

	@Override
	@RequestMapping(value = URIConstants.SUGGEST_TRAINING_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getSuggestedTrainingList(@RequestBody TrainingList trainingList) throws Exception {
		List<SuggestedTraining> result = trainingListService.getSuggestedTrainingList(trainingList);
		if (result != null) {
			Map<String, List<SuggestedTraining>> map = new HashMap<String, List<SuggestedTraining>>();
			map.put("trainingSuggestions", result);
			return new ResponseEntity<Map<String, List<SuggestedTraining>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("errorMessage", "Send proper request body");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
	}
}
