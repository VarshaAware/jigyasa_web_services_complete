/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 27-Apr-2017
>  * CreateNewTrainingControllerImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.CreateNewTrainingController;
import com.exilant.jigyasa.service.CreateNewTrainingService;
import com.exilant.jigyasa.vo.CreateNewTraining;

/**
 * @author swathi.m
 *
 */
@RestController
public class CreateNewTrainingControllerImpl implements CreateNewTrainingController {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.controller.CreateNewTrainingController#
	 * createNewTrainingHandler(com.exilant.jigyasa.vo.CreateNewTraining)
	 */

	@Autowired
	CreateNewTrainingService createNewTrainingService;

	@Override
	@RequestMapping(value = URIConstants.CREATE_NEW_TRAINING, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> createNewTrainingHandler(@RequestBody CreateNewTraining createNewTraining)
			throws Exception {
		int createsNewTraining = createNewTrainingService.createNewTrainingService(createNewTraining);
		Map<String, Integer> map = new HashMap<>();
		map.put("trainingId", createsNewTraining);
		if (createsNewTraining != 0) {

			return new ResponseEntity<Map<String, Integer>>(map, HttpStatus.OK);

		}
		Map<String, String> errorMap = new HashMap<String, String>();
		errorMap.put("errorMessage", "someError");
		return new ResponseEntity<Map<String, String>>(errorMap, HttpStatus.OK);
	}

}