package com.exilant.jigyasa.repository.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.RequestTrainingRepository;
import com.exilant.jigyasa.vo.Employee;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.Scheduled_Training;

@Repository
public class MySqlRequestTrainingRepository implements RequestTrainingRepository {
	static final Logger logger = LoggerFactory.getLogger(MySqlRequestTrainingRepository.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public String scheduledTraining(RequestTraining scheduledTrainingRequest) {

		String query = SqlQueryConstants.GET_SCHEDULED_TRAINING;
		int input = scheduledTrainingRequest.getTrainingId();
		Scheduled_Training trainingObj = null;
		try {
			trainingObj = (Scheduled_Training) jdbcTemplate.queryForObject(query, new Object[] { input },
					(rs, rowNum) -> {
						Scheduled_Training obj = new Scheduled_Training();
						obj.setScheduled_Training_Id(rs.getInt(1) + "");
						return obj;
					});
		} catch (Exception e) {
			logger.error("Selection of training failed: No vaild TrainingID");
			return "Selectionoftrainingfailed";
		}

		String query1 = SqlQueryConstants.GET_EMPLOYEE_NAME;
		int input1 = scheduledTrainingRequest.getEmployeeId();
		Employee trainingObj1 = null;
		try {
			trainingObj1 = jdbcTemplate.queryForObject(query1, new Object[] { input1 }, (rs, rowNum) -> {
				Employee obj = new Employee();
				obj.setEmployeeId(rs.getInt(1));
				obj.setEmployeeName(rs.getString(2));
				return obj;
			});
		} catch (Exception e) {
			logger.error("Selection failed: no vaild employeeID");
			return "Selectionfailed";
		}

		if (trainingObj != null) {
			try {

				String sql = SqlQueryConstants.INSERT_REQUEST_TRAINING;
				Object[] queryParameters = new Object[] { scheduledTrainingRequest.getTrainingId(),
						scheduledTrainingRequest.getEmployeeId(), trainingObj1.getEmployeeName(),
						scheduledTrainingRequest.getManagerId() };

				jdbcTemplate.update(sql, queryParameters);
				return "inserted";
			} catch (Exception e) {
				logger.error("Insertion failed: Request already exits");
				return "alreadyexits";
			}
		}

		return "someerror";

	}

}
