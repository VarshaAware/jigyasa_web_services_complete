package com.exilant.jigyasa.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestedEmployeeList {
	@JsonProperty("Training_requestor_Id")
	private String employeeId;
	@JsonProperty("Scheduled_Training_Id")
	private String trainingId;
	private String Training_requestor_ManagerId;
	private String Status;
	private String Modified_Date;
	private String Created_By;
	private String Request_Id;
	private String Training_requestor_Name;
	private String  Created_Date;
	private String Modified_By;
	
	

	public String getTraining_requestor_ManagerId() {
		return Training_requestor_ManagerId;
	}
	
	@JsonProperty("Training_requestor_ManagerId")
	public void setTraining_requestor_ManagerId(String training_requestor_ManagerId) {
		Training_requestor_ManagerId = training_requestor_ManagerId;
	}
	public String getStatus() {
		return Status;
	}
	@JsonProperty("Status")
	public void setStatus(String status) {
		Status = status;
	}
	public String getModified_Date() {
		return Modified_Date;
	}
	@JsonProperty("Modified_Date")
	public void setModified_Date(String modified_Date) {
		Modified_Date = modified_Date;
	}
	public String getCreated_By() {
		return Created_By;
	}
	@JsonProperty("Created_By")
	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}
	public String getRequest_Id() {
		return Request_Id;
	}
	@JsonProperty("Request_Id")
	public void setRequest_Id(String request_Id) {
		Request_Id = request_Id;
	}
	public String getTraining_requestor_Name() {
		return Training_requestor_Name;
	}
	@JsonProperty("Training_requestor_Name")
	public void setTraining_requestor_Name(String training_requestor_Name) {
		Training_requestor_Name = training_requestor_Name;
	}
	public String getCreated_Date() {
		return Created_Date;
	}
	@JsonProperty("Created_Date")
	public void setCreated_Date(String created_Date) {
		Created_Date = created_Date;
	}
	public String getModified_By() {
		return Modified_By;
	}
	@JsonProperty("Modified_By")
	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}
	public String getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(String trainingId) {
		this.trainingId = trainingId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	
	public RequestedEmployeeList() {
		super();
	}
	public RequestedEmployeeList( String employeeId,String trainingId) {
		super();
		this.trainingId = trainingId;
		this.employeeId = employeeId;
	}
	
	

	public RequestedEmployeeList(String employeeId, String trainingId, String training_requestor_ManagerId,
			String status, String modified_Date, String created_By, String request_Id, String training_requestor_Name,
			String created_Date, String modified_By) {
		super();
		this.employeeId = employeeId;
		this.trainingId = trainingId;
		Training_requestor_ManagerId = training_requestor_ManagerId;
		Status = status;
		Modified_Date = modified_Date;
		Created_By = created_By;
		Request_Id = request_Id;
		Training_requestor_Name = training_requestor_Name;
		Created_Date = created_Date;
		Modified_By = modified_By;

	}
	@Override
	public String toString() {
		return "RequestedEmployeeList [employeeId=" + employeeId + ", trainingId=" + trainingId
				+ ", Training_requestor_ManagerId=" + Training_requestor_ManagerId + ", Status=" + Status
				+ ", Modified_Date=" + Modified_Date + ", Created_By=" + Created_By + ", Request_Id=" + Request_Id
				+ ", Training_requestor_Name=" + Training_requestor_Name + ", Created_Date=" + Created_Date
				+ ", Modified_By=" + Modified_By + "]";
	}

	
	
	
}
