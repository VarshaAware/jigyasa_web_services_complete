/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 08-May-2017
  * Trainer.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

/**
 * @author lakshmi.bhat
 *
 */
public class Trainer {
	private String employeeId;
	private String employeeName;
	private String contactNo;

	public Trainer() {
	}
	
	public Trainer(String employeeId, String employeeName, String contactNo) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.contactNo = contactNo;
	}

	/**
	 * @return the contactNo
	 */
	public String getContactNo() {
		return contactNo;
	}

	/**
	 * @param contactNo the contactNo to set
	 */
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	/**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId
	 *            the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName
	 *            the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Trainer [employeeId=" + employeeId + ", employeeName=" + employeeName + ", contactNo=" + contactNo
				+ "]";
	}
}
