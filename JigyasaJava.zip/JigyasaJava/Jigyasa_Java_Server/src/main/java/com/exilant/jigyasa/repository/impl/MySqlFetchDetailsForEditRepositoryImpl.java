/*******************************************************
>  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
>  * Email at <{glimpze@exilant.com}>
>  *
>  * This file is part of {project}.
>  *
>  * {project} can not be copied and/or distributed without the express
>  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
>  * 17-May-2017
>  * MySqlFetchDetailsForEditRepositoryImpl.java
>  *
>  *******************************************************/
package com.exilant.jigyasa.repository.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.exilant.jigyasa.constants.SqlQueryConstants;
import com.exilant.jigyasa.repository.FetchDetailsforEditRepository;
import com.exilant.jigyasa.vo.FetchDetailForEdit;
import com.exilant.jigyasa.vo.FetchNotification;
import com.exilant.jigyasa.vo.Training;

/**
 * @author swathi.m
 *
 */
@Repository
public class MySqlFetchDetailsForEditRepositoryImpl implements FetchDetailsforEditRepository {

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.exilant.jigyasa.repository.FetchDetailsforEditRepository#
	 * fetchDetailsForEdit(com.exilant.jigyasa.vo.Training)
	 */
	static final Logger logger = LoggerFactory.getLogger(CreateNewTrainingRepositoryImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public FetchDetailForEdit fetchDetailsForEdit(Training training) {
		// TODO Auto-generated method stub
		try {
			int courseId = 0;
			String sqlFetchDetailsCourseId = SqlQueryConstants.GET_FETCH_DETAILS_COURSE_ID;
			Object[] queryParameters = new Object[] { training.getTrainingId() };
			courseId = jdbcTemplate.queryForObject(sqlFetchDetailsCourseId, queryParameters,
					(rs, rows) -> rs.getInt(1));
			System.out.println(courseId);

			String sqlFetchTrainerDetails = SqlQueryConstants.GET_TRAINER_ID;
			List<String> trainerId = jdbcTemplate.query(sqlFetchTrainerDetails,
					new Object[] { training.getTrainingId() }, (rs, rows) -> rs.getInt(1) + "");

			FetchNotification notification = null;
			String sqlFetchnotification = SqlQueryConstants.GET_NOTIFICATION;
			Object[] fetchNotificationParameters = new Object[] { training.getTrainingId() };
			notification = jdbcTemplate.queryForObject(sqlFetchnotification, fetchNotificationParameters,
					(rs, rows) -> {
						FetchNotification fetchNotifications = new FetchNotification();
						fetchNotifications.setMailNotificationtype(rs.getString(1));
						fetchNotifications.setMailNotificationContent(rs.getString(2));
						fetchNotifications.setMailNotificationRcpType(rs.getString(3));

						return fetchNotifications;
					});
			List<String> managerIds = null;
			String sqlFetchManagerDetails = SqlQueryConstants.GET_MANAGER_ID;
			Object[] fetchManagerDetailsParameters = new Object[] { training.getTrainingId() };
			managerIds = jdbcTemplate.query(sqlFetchManagerDetails, fetchManagerDetailsParameters,
					(rs, rows) -> rs.getString(1));
			notification.setManagerId(managerIds);

			FetchDetailForEdit course = null;
			String sqlCourseDetails = SqlQueryConstants.GET_COURSE_DETAILS;
			Object[] fetchCourseDetailsParameters = new Object[] { courseId };
			course = jdbcTemplate.queryForObject(sqlCourseDetails, fetchCourseDetailsParameters, (rs, rows) -> {
				FetchDetailForEdit fetchDetail = new FetchDetailForEdit();
				fetchDetail.setCourseDescription(rs.getString(1));
				fetchDetail.setLink(rs.getString(2));

				return fetchDetail;
			});
			course.setFetchNotification(notification);
			course.setCourseId(courseId);
			course.setTrainerId(trainerId);
			return course;
		} catch (Exception e) {
			logger.error("Error message is   " + e.getMessage());
			return null;
		}

	}

}
