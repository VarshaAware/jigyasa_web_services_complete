/*******************************************************
  * Copyright (C) 2004-2017 Exilant Technologies PVT LTD.
  * Email at <{glimpze@exilant.com}>
  *
  * This file is part of Jigyasa_Java_Server
  *
  * Jigyasa_Java_Server can not be copied and/or distributed without the express
  * permission of Exilant Technologies PVT Ltd (WWW.Exilant.com)
  * 10-May-2017
  * Repotees.java
  *
  *******************************************************/

package com.exilant.jigyasa.vo;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author lakshmi.bhat
 *
 */
public class Repotees {
	private String name;
	private String empId;
	@JsonProperty("Status")
	private String status;

	public Repotees() {
	}

	public Repotees(String name, String empId, String status) {
		super();
		this.name = name;
		this.empId = empId;
		this.status = status;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}

	/**
	 * @param empId
	 *            the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
