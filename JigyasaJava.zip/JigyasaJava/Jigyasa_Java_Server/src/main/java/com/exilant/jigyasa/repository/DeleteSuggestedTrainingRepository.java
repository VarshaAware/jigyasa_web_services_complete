package com.exilant.jigyasa.repository;

import com.exilant.jigyasa.vo.SuggestTraining;

public interface DeleteSuggestedTrainingRepository {
	boolean deleteSuggestedTraining(SuggestTraining deleteSuggestedTraining);
}
