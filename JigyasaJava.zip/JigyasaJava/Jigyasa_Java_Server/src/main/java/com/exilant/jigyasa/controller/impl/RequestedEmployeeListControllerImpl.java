package com.exilant.jigyasa.controller.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.exilant.jigyasa.constants.URIConstants;
import com.exilant.jigyasa.controller.RequestedEmployeeListController;
import com.exilant.jigyasa.service.RequestedEmployeeListService;
import com.exilant.jigyasa.vo.RequestTraining;
import com.exilant.jigyasa.vo.RequestedEmployeeList;

@RestController
public class RequestedEmployeeListControllerImpl implements RequestedEmployeeListController {

	@Autowired
	RequestedEmployeeListService requestedEmployeeListService;

	@Override
	@RequestMapping(value = URIConstants.REQUEST_EMPLOYEE_LIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<?> getRequestedEmployeeList(@RequestBody RequestTraining requestedEmployeeList)
			throws Exception {
		List<RequestedEmployeeList> requestedEmployee = requestedEmployeeListService
				.getRequestedEmployeeList(requestedEmployeeList);
		// return new
		// ResponseEntity<RequestedEmployeeList>(requestedEmployee,HttpStatus.OK);

		if (requestedEmployee != null) {
			Map<String, List<RequestedEmployeeList>> map = new HashMap<String, List<RequestedEmployeeList>>();
			map.put("requestedEmployeeList", requestedEmployee);
			return new ResponseEntity<Map<String, List<RequestedEmployeeList>>>(map, HttpStatus.OK);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("errorMessage", "Send proper request body");
		return new ResponseEntity<Map<String, String>>(map, HttpStatus.BAD_REQUEST);
	}

}